package com.stepdefinition;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.base.BaseClass;
import com.manager.PageObjectManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HooksClass extends BaseClass {
	PageObjectManager pom = new PageObjectManager();
	
	@Before
	public void beforeScenario(Scenario scenario) throws FileNotFoundException, IOException {
								
		System.setProperty(getPropertyFileValue("driverKey"),getPropertyFileValue("driverPath"));
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver chdriver = new ChromeDriver(options);
		driver =  chdriver;
		driver.get(getPropertyFileValue("url"));
		maximizewindow();
		implicitWait(30);
		WebElement advanced = driver.findElement(By.xpath("//button[contains(text(),'Advanced')]"));
		advanced.click();
		WebElement advuat = driver.findElement(By.xpath("//a[text()='Proceed to ecuat.enbduat.com (unsafe)']"));
		advuat.click();
		
	}
	
	@After
	public void afterScenario(Scenario scenario) throws InterruptedException {
		if(scenario.isFailed()) {
			TakesScreenshot scrnshot = (TakesScreenshot)driver;
			byte[] screenshotAs = scrnshot.getScreenshotAs(OutputType.BYTES);
			scenario.attach(screenshotAs, "image/png", "Screen shot for failed Scenario");
		}
		
		if(pom.getLoginPage().getLogoutmenu().isDisplayed()) {
			pom.getLoginPage().logout();
			Thread.sleep(1000);
		}
		
		quitWindow();
		
		
		

	}
}
