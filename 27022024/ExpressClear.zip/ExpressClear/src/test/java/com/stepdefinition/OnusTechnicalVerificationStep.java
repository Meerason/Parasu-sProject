package com.stepdefinition;

import java.awt.AWTException;

import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;

import com.base.BaseClass;
import com.manager.PageObjectManager;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class OnusTechnicalVerificationStep extends BaseClass {
	PageObjectManager pom = new PageObjectManager();
	String onusChequeNum;
	String onusChequeAmount;
	String chequeStatus;
	String physicalchequevalidationreq="Physical Cheque Validation";
	String referral="Response awaiting from Referral Channel";
	

	@When("User is on Onus Technical Verification {string}")
	public void user_is_on_onus_technical_verification(String batchNum) throws Exception {
	   pom.getOnusTechnicalverification().onusMaker(batchNum);
	   Thread.sleep(10000);
	   onusChequeNum = pom.getOnusTechnicalverification().onusChequeNum();
	   System.out.println("Cheque Number:" + onusChequeNum);
	  	   }
	
	@When("User update the amount and return Cheque by maker in Onus {string}")
	public void user_update_the_amount_and_return_cheque_by_maker_in_onus(String chequeAmount) throws Exception {
		pom.getOnusTechnicalverification().onusReturnMaker(chequeAmount);
		
		onusChequeAmount=chequeAmount;
		System.out.println("Cheque Amount:" + onusChequeAmount);
		
	}

	@When("Cheque with above the specified limit Login with Checker for Onus {string},{string}")
	public void cheque_with_above_the_specified_limit_login_with_checker_for_onus(String chkuserName, String chkpassword) throws Exception {
		String chequeVal = onusChequeAmount.replaceAll(",", "");
		double chequeValue = Double.parseDouble(chequeVal);
		if (chequeValue >= 10000) {
			pom.getLoginPage().logout();
			pom.getLoginPage().login(chkuserName, chkpassword);
			pom.getLoginPage().loginPopMsg();
			pom.getOnusTechnicalverification().onusChecker(onusChequeNum);
			pom.getOnusTechnicalverification().onusReturnByChecker(onusChequeAmount);

		}else {
			System.out.println("=================  No need Checker  =================");
			}
		
	}

	@When("User update the amount and Accept Cheque by maker in Onus {string}")
	public void user_update_the_amount_and_accept_cheque_by_maker_in_onus(String chequeAmount) throws AWTException, InterruptedException {
		pom.getOnusTechnicalverification().onusAcceptByMaker(chequeAmount);
		onusChequeAmount=chequeAmount;
		System.out.println("Cheque Amount:" + onusChequeAmount);
	}
	@When("Cheque with above the specified limit Login with Checker for Onus and accept {string},{string}")
	public void cheque_with_above_the_specified_limit_login_with_checker_for_onus_and_accept(String chkuserName, String chkpassword) throws AWTException, InterruptedException {
		String chequeVal = onusChequeAmount.replaceAll(",", "");
		double chequeValue = Double.parseDouble(chequeVal);
		if (chequeValue >= 10000) {
			pom.getLoginPage().logout();
			pom.getLoginPage().login(chkuserName, chkpassword);
			pom.getLoginPage().loginPopMsg();
			pom.getOnusTechnicalverification().onusChecker(onusChequeNum);
			pom.getOnusTechnicalverification().onusAcceptByChecker(onusChequeAmount);

		}else {
			System.out.println("=================  No need Checker  =================");
			}
		
	}

	@Then("User verifying Cheque status in SearchItemFinder")
	public void user_verifying_cheque_status_in_search_item_finder() throws Exception {
		pom.getOnusTechnicalverification().search_ItemFinder(onusChequeNum, onusChequeAmount);
		Thread.sleep(1500);
		chequeStatus = pom.getOnusTechnicalverification().onuschequeStatus();
		System.out.println("Without refferral & physical cheque validation Cheque Status:" + chequeStatus);
		if(chequeStatus.contains(referral)||chequeStatus==referral) {
			pom.getOnusTechnicalverification().onusParallelReferralProcessing(onusChequeNum);
			pom.getOnusTechnicalverification().search_ItemFinder(onusChequeNum, onusChequeAmount);
			Thread.sleep(1500);
			chequeStatus = pom.getInwardTechnicalVerifier().chequeStatus();
			System.out.println("After Referral Process Cheque Status:" + chequeStatus);
		}
		if(chequeStatus.contains(physicalchequevalidationreq)||chequeStatus==physicalchequevalidationreq) {
			pom.getOnusTechnicalverification().physicalChequeValidation(onusChequeNum);
			pom.getOnusTechnicalverification().search_ItemFinder(onusChequeNum, onusChequeAmount);
			Thread.sleep(1500);
			chequeStatus = pom.getInwardTechnicalVerifier().chequeStatus();
			System.out.println("After Physical cheque Validation Cheque Status:" + chequeStatus);
		}
	}

	/**
	 * @author ParasuramK Onus Branch Cheque Capture Field Verification
	 */

	@Then("User verify Onus Branch Cheque Capture Is Clickable")
	public void user_verify_onus_branch_cheque_capture_is_clickable() {
		boolean onusBranchChequeCaptureIsClickable = pom.getOnusTechnicalverification().onusBranchChequeCaptureIsClickable();
		Assert.assertTrue(onusBranchChequeCaptureIsClickable);
		System.out.println("Onus Branch Cheque Capture Is Clickable: "+onusBranchChequeCaptureIsClickable);
	}
	@Then("User Verify Presentation Type is Mandatory")
	public void user_verify_presentation_type_is_mandatory() {
	    boolean presentationTypeisMandatory = pom.getOnusTechnicalverification().presentationTypeisMandatory();
	    Assert.assertTrue(presentationTypeisMandatory);
	    System.out.println("Presentation Type Mandatory Msg Is Displayed: " + presentationTypeisMandatory);
	}
	@Then("User Verify Scanner Type is Mandadtory")
	public void user_verify_scanner_type_is_mandadtory() {
	    boolean scannerTypeisMandatory = pom.getOnusTechnicalverification().scannerTypeisMandatory();
	    Assert.assertTrue(scannerTypeisMandatory);
	    System.out.println("Scanner Type Mandatory Msg Is Displayed: "+scannerTypeisMandatory);
	}
	@Then("User Verify Initialize button is Clickable")
	public void user_verify_initialize_button_is_clickable() {
	   boolean initializebuttonisClickable = pom.getOnusTechnicalverification().initializebuttonisClickable();
	   Assert.assertTrue(initializebuttonisClickable);
	   System.out.println("Initialize Button is Clickable: "+initializebuttonisClickable);
	}
	@Then("User Verify Start button is Clickable")
	public void user_verify_start_button_is_clickable() {
	    boolean startbuttonisClickable = pom.getOnusTechnicalverification().startbuttonisClickable();
	    Assert.assertTrue(startbuttonisClickable);
	    System.out.println("Start Button is Clickable: "+ startbuttonisClickable);
	}
	@Then("User Verify Stop button is Clickable")
	public void user_verify_stop_button_is_clickable() {
	    boolean stopbuttonisClickable = pom.getOnusTechnicalverification().stopbuttonisClickable();
	    Assert.assertTrue(stopbuttonisClickable);
	    System.out.println("Stop Button is Clickable: "+stopbuttonisClickable);
	}
	@Then("User Verify Finish button is Clickable")
	public void user_verify_finish_button_is_clickable() {
	   boolean finishbuttonisClickable = pom.getOnusTechnicalverification().finishbuttonisClickable();
	   Assert.assertTrue(finishbuttonisClickable);
	   System.out.println("Finish Button is Clickable: "+finishbuttonisClickable);
	}

	/**
	 * @author ParasuramK Scan Verification Field Verification
	 */
	
	@Then("User Verify Scan Verification Is Clickable")
	public void user_verify_scan_verification_is_clickable() {
	   boolean scanVerificationIsClickable = pom.getOnusTechnicalverification().scanVerificationIsClickable();
	   Assert.assertTrue(scanVerificationIsClickable);
	   System.out.println("Scan Verification Is Clickable: " + scanVerificationIsClickable);
	}
	@Then("User Verify The Business Date Mandatory Field")
	public void user_verify_the_business_date_mandatory_field() {
	    boolean scanVerificationBusinessDateisMandatory = pom.getOnusTechnicalverification().scanVerificationBusinessDateisMandatory();
	    Assert.assertTrue(scanVerificationBusinessDateisMandatory);
	    System.out.println("Scan Verification Business Date is Mandatory: "+scanVerificationBusinessDateisMandatory);
	}
	@Then("User Verify Search button Is Clickable")
	public void user_verify_search_button_is_clickable() {
	    boolean scanVerificationSearchButtonisClickable = pom.getOnusTechnicalverification().scanVerificationSearchButtonisClickable();
	    Assert.assertTrue(scanVerificationSearchButtonisClickable);
	    System.out.println("Scan Verification Search Button is Clickable: "+scanVerificationSearchButtonisClickable);
	}

	/**
	 * @author ParasuramK Onus OPC Reject Repair Maker Field Verification
	 */
	
	@Then("User Verify Onus OPC Reject Repair Maker Is Clickable")
	public void user_verify_onus_opc_reject_repair_maker_is_clickable() {
	    boolean onusOPCRejectRepairMakerIsClickable = pom.getOnusTechnicalverification().onusOPCRejectRepairMakerIsClickable();
	    Assert.assertTrue(onusOPCRejectRepairMakerIsClickable);
	    System.out.println("Onus OPC Reject Repair Maker Is Clickable: "+onusOPCRejectRepairMakerIsClickable);
	}
	@Then("User Verify The OPC Reject Repair Maker Business Date is Mandatory Field")
	public void user_verify_the_opc_reject_repair_maker_business_date_is_mandatory_field() {
	   boolean onusOPCRejectRepairMakerBusinessDateisMandatory = pom.getOnusTechnicalverification().onusOPCRejectRepairMakerBusinessDateisMandatory();
	   Assert.assertTrue(onusOPCRejectRepairMakerBusinessDateisMandatory);
	   System.out.println("Onus OPC Reject Repair Maker Business Date is Mandatory: "+onusOPCRejectRepairMakerBusinessDateisMandatory);
	}
	@Then("User Verify OPC Reject Repair Maker Search button Is Clickable")
	public void user_verify_opc_reject_repair_maker_search_button_is_clickable() {
	    boolean onusOPCRejectRepairMakerSearchButtonisClickable = pom.getOnusTechnicalverification().onusOPCRejectRepairMakerSearchButtonisClickable();
	    Assert.assertTrue(onusOPCRejectRepairMakerSearchButtonisClickable);
	    System.out.println("Onus OPC Reject Repair Maker Search Button is Clickable: "+onusOPCRejectRepairMakerSearchButtonisClickable);
	}
	/**
	 * @author ParasuramK Physical Cheque Validation Field Verification
	 */

	@Then("User Verify Physical Cheque validation is Clickable")
	public void user_verify_physical_cheque_validation_is_clickable() {
	    boolean physicalChequevalidationisClickable = pom.getOnusTechnicalverification().physicalChequevalidationisClickable();
	    Assert.assertTrue(physicalChequevalidationisClickable);
	    System.out.println("Physical Cheque validation Menu is Clickable: "+physicalChequevalidationisClickable);
	}
	@Then("User Verify The Physical Cheque Validation Business Date is Mandatory Field")
	public void user_verify_the_physical_cheque_validation_business_date_is_mandatory_field() {
		 boolean physicalChequeValidationBusinessDateMandatoryField = pom.getOnusTechnicalverification().physicalChequeValidationBusinessDateMandatoryField();
		 Assert.assertTrue(physicalChequeValidationBusinessDateMandatoryField);
		 System.out.println("Physical Cheque Validation Business Date is Mandatory Field: "+ physicalChequeValidationBusinessDateMandatoryField);
		 
	}
	@Then("User Verify Physical Cheque Validation Search button Is Clickable")
	public void user_verify_physical_cheque_validation_search_button_is_clickable() {
		 boolean physicalChequeValidationSearchButtonIsClickable = pom.getOnusTechnicalverification().physicalChequeValidationSearchButtonIsClickable();
		 Assert.assertTrue(physicalChequeValidationSearchButtonIsClickable);
		 System.out.println("Physical Cheque Validation Search Button Is Clickable: "+ physicalChequeValidationSearchButtonIsClickable);
	}
	@Then("User Verify Physical Cheque Validation Batch details Clickable")
	public void user_verify_physical_cheque_validation_batch_details_clickable() throws InterruptedException {
		boolean physicalChequeValidationBatchDetailisClickable = pom.getOnusTechnicalverification().physicalChequeValidationBatchDetailisClickable();
		Assert.assertTrue(physicalChequeValidationBatchDetailisClickable);
		System.out.println("Physical Cheque Validation Batch Detail is Clickable: " + physicalChequeValidationBatchDetailisClickable);
	}
	@Then("User Verify Back,Verify & Delete button is Clickable")
	public void user_verify_back_verify_delete_button_is_clickable() {
	   boolean physicalChequeValidationBatchDetailBackbuttonisClickable = pom.getOnusTechnicalverification().physicalChequeValidationBatchDetailBackbuttonisClickable();
	   Assert.assertTrue(physicalChequeValidationBatchDetailBackbuttonisClickable);
	   System.out.println("Physical Cheque Validation Batch Detail Back button is Clickable: "+ physicalChequeValidationBatchDetailBackbuttonisClickable);
	   boolean physicalChequeValidationBatchDetailVerifybuttonisClickable = pom.getOnusTechnicalverification().physicalChequeValidationBatchDetailVerifybuttonisClickable();
	   Assert.assertTrue(physicalChequeValidationBatchDetailVerifybuttonisClickable);
	   System.out.println("Physical Cheque Validation Batch Detail Verify button is Clickable: "+physicalChequeValidationBatchDetailVerifybuttonisClickable);
	   boolean physicalChequeValidationBatchDetailDeletebuttonisClickable = pom.getOnusTechnicalverification().physicalChequeValidationBatchDetailDeletebuttonisClickable();
	   Assert.assertTrue(physicalChequeValidationBatchDetailDeletebuttonisClickable);
	   System.out.println("Physical Cheque Validation Batch Detail Delete button is Clickable: "+physicalChequeValidationBatchDetailDeletebuttonisClickable);
	}

	   /**
	    * @author ParasuramK Checkerwise Verified SatusField Verification
	    */

	@Then("User Verify Checker Wise Verified Status is Clickable")
	public void user_verify_checker_wise_verified_status_is_clickable() {
	    boolean checkerWiseVerifiedStatusisClickable = pom.getOnusTechnicalverification().checkerWiseVerifiedStatusisClickable();
	    Assert.assertTrue(checkerWiseVerifiedStatusisClickable);
	    System.out.println("CheckerWise Verified Status is Clickable: " + checkerWiseVerifiedStatusisClickable);
	}
	@Then("User Verify Checker Wise Verified Status Refresh button is Clickable")
	public void user_verify_checker_wise_verified_status_refresh_button_is_clickable() {
	    boolean checkerWiseVerifiedStatusRefreshbuttonisClickable = pom.getOnusTechnicalverification().checkerWiseVerifiedStatusRefreshbuttonisClickable();
	    Assert.assertTrue(checkerWiseVerifiedStatusRefreshbuttonisClickable);
	    System.out.println("CheckerWise Verified Status Refresh button is Clickable:" + checkerWiseVerifiedStatusRefreshbuttonisClickable);
	}

	/**
     * @author ParasuramK Makerwise Processing status Field Verification
     */

	@Then("User Verify Makerwise Processing Status is Clickable")
	public void user_verify_makerwise_processing_status_is_clickable() {
		boolean makerwiseProcessingStatusisClickable = pom.getOnusTechnicalverification().makerwiseProcessingStatusisClickable();
		Assert.assertTrue(makerwiseProcessingStatusisClickable);
		System.out.println("Makerwise Processing Status is Clickable: " + makerwiseProcessingStatusisClickable);
	}
	@Then("User Verify Makerwise Processing status Refresh button is Clickable")
	public void user_verify_makerwise_processing_status_refresh_button_is_clickable() {
	   boolean makerwiseProcessingStatusRefreshbuttonisClickable = pom.getOnusTechnicalverification().makerwiseProcessingStatusRefreshbuttonisClickable();
	   Assert.assertTrue(makerwiseProcessingStatusRefreshbuttonisClickable);
	   System.out.println("Makerwise Processing Status Refresh button is Clickable: " + makerwiseProcessingStatusRefreshbuttonisClickable);
	}
	/**
     * @author ParasuramK Onus ChannelWise Processing Status Dashboard Field Verification
     */
	
	@Then("User Verify Onus ChannelWise Processing Status Dashboard is Clickable")
	public void user_verify_onus_channel_wise_processing_status_dashboard_is_clickable() {
	    boolean onusChannelWiseProcessingStatusDashboardisClickable = pom.getOnusTechnicalverification().onusChannelWiseProcessingStatusDashboardisClickable();
	    Assert.assertTrue(onusChannelWiseProcessingStatusDashboardisClickable);
	    System.out.println("Onus ChannelWise Processing Status Dashboard is Clickable: "+ onusChannelWiseProcessingStatusDashboardisClickable);	
	}
	@Then("User Verify Onus ChannelWise Processing Status Dashboard Refresh button is Clickable")
	public void user_verify_onus_channel_wise_processing_status_dashboard_refresh_button_is_clickable() {
	    boolean onusChannelWiseProcessingStatusDashboardRefreshbuttonisClickable = pom.getOnusTechnicalverification().onusChannelWiseProcessingStatusDashboardRefreshbuttonisClickable();
	    Assert.assertTrue(onusChannelWiseProcessingStatusDashboardRefreshbuttonisClickable);
	    System.out.println("Onus ChannelWise Processing Status Dashboard Refresh button is Clickable: "+onusChannelWiseProcessingStatusDashboardRefreshbuttonisClickable);
	}

	@Then("User Verify Onus Finacle Dashboard is Clickable")
	public void user_verify_onus_finacle_dashboard_is_clickable() {
	    boolean onusFinacleDashboardisClickable = pom.getOnusTechnicalverification().onusFinacleDashboardisClickable();
	    Assert.assertTrue(onusFinacleDashboardisClickable);
	    System.out.println("Onus Finacle Dashboard is Clickable: "+ onusFinacleDashboardisClickable);
	}
	@Then("User Verify Onus Finacle Dashboard Refresh button is Clickable")
	public void user_verify_onus_finacle_dashboard_refresh_button_is_clickable() {
	   boolean onusFinacleDashboardRefreshbuttonisClickable = pom.getOnusTechnicalverification().onusFinacleDashboardRefreshbuttonisClickable();
	   Assert.assertTrue(onusFinacleDashboardRefreshbuttonisClickable);
	   System.out.println("Onus Finacle Dashboard Refresh button is Clickable: "+onusFinacleDashboardRefreshbuttonisClickable);
	}
	/**
     * @author ParasuramK Onus Refferal Dashboard Field Verification
     */
	@Then("User Verify Onus Refferal Dashboard is Clickable")
	public void user_verify_onus_refferal_dashboard_is_clickable() {
	    boolean onusRefferalDashboardisClickable = pom.getOnusTechnicalverification().onusRefferalDashboardisClickable();
	    Assert.assertTrue(onusRefferalDashboardisClickable);
	    System.out.println("Onus Refferal Dashboard is Clickable:"+onusRefferalDashboardisClickable);
	}
	@Then("User Verify Onus Refferal Dashboard Refresh button is Clickable")
	public void user_verify_onus_refferal_dashboard_refresh_button_is_clickable() throws InterruptedException {
		boolean onusRefferalDashboardRefreshbuttonisClickable = pom.getOnusTechnicalverification().onusRefferalDashboardRefreshbuttonisClickable();
		Assert.assertTrue(onusRefferalDashboardRefreshbuttonisClickable);
		System.out.println("Onus Refferal Dashboard Refresh button is Clickable: "+onusRefferalDashboardRefreshbuttonisClickable);
	}

	 /**
     * @author ParasuramK Onus Branch Referral Crad Field Verification
     */

	@Then("User Verify Onus Branch Referral Crad Is Clickable")
	public void user_verify_onus_branch_referral_crad_is_clickable() {
	   boolean onusBranchReferralCradIsClickable = pom.getOnusTechnicalverification().onusBranchReferralCradIsClickable();
	   Assert.assertTrue(onusBranchReferralCradIsClickable);
	   System.out.println("Onus Branch Referral Crad Is Clickable: "+onusBranchReferralCradIsClickable);
	}
	@Then("User Verify Onus Branch Referral Crad The Business Date Mandatory Field")
	public void user_verify_onus_branch_referral_crad_the_business_date_mandatory_field() {
	   boolean onusBranchReferralCradTheBusinessDateMandatoryField = pom.getOnusTechnicalverification().onusBranchReferralCradTheBusinessDateMandatoryField();
	   Assert.assertTrue(onusBranchReferralCradTheBusinessDateMandatoryField);
	   System.out.println("Onus Branch Referral Crad The Business Date Mandatory Field: "+ onusBranchReferralCradTheBusinessDateMandatoryField);
	   pom.getOnusTechnicalverification().acceptOKMsg();
	}
	@Then("User Verify Onus Branch Referral Crad Search button Is Clickable")
	public void user_verify_onus_branch_referral_crad_search_button_is_clickable() {
	    boolean onusBranchReferralCradSearchbuttonIsClickable = pom.getOnusTechnicalverification().onusBranchReferralCradSearchbuttonIsClickable();
	    Assert.assertTrue(onusBranchReferralCradSearchbuttonIsClickable);
	    System.out.println("Onus Branch Referral Crad Search button Is Clickable: "+onusBranchReferralCradSearchbuttonIsClickable);
	}
	@Then("User Verify Onus Branch Referral Crad Batch details are Clickable")
	public void user_verify_onus_branch_referral_crad_batch_details_are_clickable() throws InterruptedException {
	    boolean onusBranchReferralCradBatchdetailsareClickable = pom.getOnusTechnicalverification().onusBranchReferralCradBatchdetailsareClickable();
	    Assert.assertTrue(onusBranchReferralCradBatchdetailsareClickable);
	    System.out.println("Onus Branch Referral Crad Batch details are Clickable: "+ onusBranchReferralCradBatchdetailsareClickable);	
	}
	@Then("User Verify Onus Branch Referral Crad Back,Accept & Return button is Clickable")
	public void user_verify_onus_branch_referral_crad_back_accept_return_button_is_clickable() {
	   boolean onusBranchReferralCradBackbuttonisClickable = pom.getOnusTechnicalverification().onusBranchReferralCradBackbuttonisClickable();
	   Assert.assertTrue(onusBranchReferralCradBackbuttonisClickable);
	   System.out.println("Onus Branch Referral Crad Back button is Clickable: "+onusBranchReferralCradBackbuttonisClickable);
	   boolean onusBranchReferralCradAcceptbuttonisClickable = pom.getOnusTechnicalverification().onusBranchReferralCradAcceptbuttonisClickable();
	   Assert.assertTrue(onusBranchReferralCradAcceptbuttonisClickable);
	   System.out.println("Onus Branch Referral Crad Accept button is Clickable: "+onusBranchReferralCradAcceptbuttonisClickable);
	   boolean onusBranchReferralCradReturnbuttonisClickable = pom.getOnusTechnicalverification().onusBranchReferralCradReturnbuttonisClickable();
	   Assert.assertTrue(onusBranchReferralCradReturnbuttonisClickable);
	   System.out.println("Onus Branch Referral Crad Return button is Clickable: "+onusBranchReferralCradReturnbuttonisClickable);
	}
	/**
     * @author ParasuramK Onus Dashboard Field Verification
     */
	
	@Then("User Verify Onus Dashboard is Clikable")
	public void user_verify_onus_dashboard_is_clikable() {
	    boolean onusDashboardisClikable = pom.getOnusTechnicalverification().onusDashboardisClikable();
	    Assert.assertTrue(onusDashboardisClikable);
	    System.out.println("Onus Dashboard is Clikable: " + onusDashboardisClikable);
	    pom.getOnusTechnicalverification().onusDashboard();
	}
	@Then("User Verify Total Cheque Scanned- plus icon is Clikable")
	public void user_verify_total_cheque_scanned_plus_icon_is_clikable() {
	   boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconTotalChequeScanned().isEnabled();
	   Assert.assertTrue(enabled);
	   System.out.println("Total Cheque Scanned- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify QR Code Validation- plus icon is Clikable")
	public void user_verify_qr_code_validation_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconQRCodeValidation().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("QR Code Validation- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify ICR Service- plus icon is Clikable")
	public void user_verify_icr_service_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconICRService().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("ICR Service- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify Technical Verification I with Data Entry \\(OPC)- plus icon is Clikable")
	public void user_verify_technical_verification_i_with_data_entry_opc_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconTechnicalVerificationI().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Technical Verification I with Data Entry(OPC)- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify Technical Verification II \\(OPC)- plus icon is Clikable")
	public void user_verify_technical_verification_ii_opc_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconTechnicalVerificationII().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Technical Verification II (OPC)- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify Branch Referral Crad- plus icon is Clikable")
	public void user_verify_branch_referral_crad_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconBranchReferralCrad().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Branch Referral Crad- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify Posting to Finacle- plus icon is Clikable")
	public void user_verify_posting_to_finacle_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconPostingtoFinacle().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Posting to Finacle- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify ACE File Creation- plus icon is Clikable")
	public void user_verify_ace_file_creation_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconACEFileCreation().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("ACE File Creation- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify ACE ACK File Parsing- plus icon is Clikable")
	public void user_verify_ace_ack_file_parsing_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconACEACKFileParsing().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("ACE ACK File Parsing- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify NACK Reject Reprocessing- plus icon is Clikable")
	public void user_verify_nack_reject_reprocessing_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconNACKRejectReprocessing().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("NACK Reject Reprocessing- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify Channel Wise cheque Status Count- plus icon is Clikable")
	public void user_verify_channel_wise_cheque_status_count_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconChannelWisechequeStatusCount().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Channel Wise cheque Status Count- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify Finacle- plus icon is Clikable")
	public void user_verify_finacle_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconFinacle().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Finacle- plus icon is Clikable: "+enabled);
	}
	@Then("User Verify Awaiting- plus icon is Clikable")
	public void user_verify_awaiting_plus_icon_is_clikable() {
		boolean enabled = pom.getOnusTechnicalverification().getOnusDashboardPlusIconAwaiting().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Awaiting- plus icon is Clikable: "+enabled);
	}

	/**
     * @author ParasuramK Onus OPC Arabic Reject Repair Maker Field Verification
     */

	@Then("User Verify Onus OPC Arabic Reject Repair Maker Is Clickable")
	public void user_verify_onus_opc_arabic_reject_repair_maker_is_clickable() {
	    boolean onusOPCArabicRejectRepairMakerIsClickable = pom.getOnusTechnicalverification().onusOPCArabicRejectRepairMakerIsClickable();
	    Assert.assertTrue(onusOPCArabicRejectRepairMakerIsClickable);
	    System.out.println("Onus OPC Arabic Reject Repair Maker Is Clickable: " + onusOPCArabicRejectRepairMakerIsClickable);
	}
	@Then("User Verify Onus OPC Arabic Reject Repair Maker Business Date is Mandatory Field")
	public void user_verify_onus_opc_arabic_reject_repair_maker_business_date_is_mandatory_field() {
		boolean onusOPCArabicRejectRepairMakerBusinessDateisMandatory = pom.getOnusTechnicalverification().onusOPCArabicRejectRepairMakerBusinessDateisMandatory();
	    Assert.assertTrue(onusOPCArabicRejectRepairMakerBusinessDateisMandatory);
	    System.out.println("Onus OPC Arabic Reject Repair Maker Business Date is Mandatory: "+onusOPCArabicRejectRepairMakerBusinessDateisMandatory);
	    pom.getOnusTechnicalverification().acceptOKMsg();
	}
	@Then("User Verify Onus OPC Arabic Reject Repair Maker Search button Is Clickable")
	public void user_verify_onus_opc_arabic_reject_repair_maker_search_button_is_clickable() {
	    boolean onusOPCArabicRejectRepairMakerSearchbuttonIsClickable = pom.getOnusTechnicalverification().onusOPCArabicRejectRepairMakerSearchbuttonIsClickable();
	    Assert.assertTrue(onusOPCArabicRejectRepairMakerSearchbuttonIsClickable);
	    System.out.println("Onus OPC Arabic Reject Repair Maker Search button Is Clickable: "+ onusOPCArabicRejectRepairMakerSearchbuttonIsClickable);
	}
	@Then("User Verify Onus OPC Arabic Reject Repair Maker Batch details Clickable")
	public void user_verify_onus_opc_arabic_reject_repair_maker_batch_details_clickable() throws InterruptedException {
	    try {
	    boolean onusOPCArabicRejectRepairMakerBatchdetailsareClickable = pom.getOnusTechnicalverification().onusOPCArabicRejectRepairMakerBatchdetailsareClickable();
	    Assert.assertTrue(onusOPCArabicRejectRepairMakerBatchdetailsareClickable);
	    System.out.println("Onus OPC Arabic Reject Repair Maker Batch details are Clickable: "+ onusOPCArabicRejectRepairMakerBatchdetailsareClickable);
	    }
	    catch(NoSuchElementException e) {
	    	pom.getOnusTechnicalverification().acceptOKMsg();
	    	System.out.println("No Batch Found to verify Batch details");
	    }
	}
	@Then("User Verify Onus OPC Arabic Reject Repair Maker Delete,Back & Release Lock button Clickable")
	public void user_verify_onus_opc_arabic_reject_repair_maker_delete_back_release_lock_button_clickable() {
	    try {
	    boolean onusOPCArabicRejectRepairMakerBackbuttonisClickable = pom.getOnusTechnicalverification().onusOPCArabicRejectRepairMakerBackbuttonisClickable();
	    Assert.assertTrue(onusOPCArabicRejectRepairMakerBackbuttonisClickable);
	    System.out.println("Onus OPC Arabic Reject Repair Maker Back button is Clickable: "+onusOPCArabicRejectRepairMakerBackbuttonisClickable);
	    boolean onusOPCArabicRejectRepairMakerReleaseLockbuttonisClickable = pom.getOnusTechnicalverification().onusOPCArabicRejectRepairMakerReleaseLockbuttonisClickable();
	    Assert.assertTrue(onusOPCArabicRejectRepairMakerReleaseLockbuttonisClickable);
	    System.out.println("Onus OPC Arabic Reject Repair Maker Release Lock button is Clickable: "+onusOPCArabicRejectRepairMakerReleaseLockbuttonisClickable);
	    boolean onusOPCArabicRejectRepairMakerDeletebuttonisClickable = pom.getOnusTechnicalverification().onusOPCArabicRejectRepairMakerDeletebuttonisClickable();
	    Assert.assertTrue(onusOPCArabicRejectRepairMakerDeletebuttonisClickable);
	    System.out.println("onusOPCArabicRejectRepairMakerDeletebuttonisClickable: "+ onusOPCArabicRejectRepairMakerDeletebuttonisClickable);
	    }
	    catch(NoSuchElementException e) {
	    	System.out.println("No Batch Found to Verify Button Field");
	    }
	}
	
	/**
	 * @author ParasuramK Onus Parallel Referral Processing Field Verification
	 */

	@Then("User Verify Onus Parallel Referral Processing Is Clickable")
	public void user_verify_onus_parallel_referral_processing_is_clickable() {
	    boolean onusParallelReferralProcessingIsClickable = pom.getOnusTechnicalverification().onusParallelReferralProcessingIsClickable();
	    Assert.assertTrue(onusParallelReferralProcessingIsClickable);
	    System.out.println("Onus Parallel Referral Processing Is Clickable: "+onusParallelReferralProcessingIsClickable);
	}
	@Then("User Verify Onus Parallel Referral Processing Business Date is Mandatory Field")
	public void user_verify_onus_parallel_referral_processing_business_date_is_mandatory_field() {
	    boolean onusParallelReferralProcessingBusinessDateisMandatory = pom.getOnusTechnicalverification().onusParallelReferralProcessingBusinessDateisMandatory();
	    Assert.assertTrue(onusParallelReferralProcessingBusinessDateisMandatory);
	    System.out.println("Onus Parallel Referral Processing Business Date is Mandatory: "+ onusParallelReferralProcessingBusinessDateisMandatory);
	    pom.getOnusTechnicalverification().acceptOKMsg();
	}
	@Then("User Verify Onus Parallel Referral Processing Search button Is Clickable")
	public void user_verify_onus_parallel_referral_processing_search_button_is_clickable() {
		boolean onusParallelReferralProcessingSearchbuttonIsClickable = pom.getOnusTechnicalverification().onusParallelReferralProcessingSearchbuttonIsClickable();
		Assert.assertTrue(onusParallelReferralProcessingSearchbuttonIsClickable);
		System.out.println("Onus Parallel Referral Processing Search button Is Clickable: "+ onusParallelReferralProcessingSearchbuttonIsClickable);
	}
	@Then("User Verify Onus Parallel Referral Processing Batch details Clickable")
	public void user_verify_onus_parallel_referral_processing_batch_details_clickable() throws InterruptedException {
		boolean onusParallelReferralProcessingBatchdetailsareClickable = pom.getOnusTechnicalverification().onusParallelReferralProcessingBatchdetailsareClickable();
		Assert.assertTrue(onusParallelReferralProcessingBatchdetailsareClickable);
		System.out.println("Onus Parallel Referral Processing Batch details are Clickable: "+onusParallelReferralProcessingBatchdetailsareClickable);
	}
	@Then("User Verify Onus Parallel Referral Processing Back,Accept & Return button Clickable")
	public void user_verify_onus_parallel_referral_processing_back_accept_return_button_clickable() {
		boolean onusParallelReferralProcessingBackbuttonisClickable = pom.getOnusTechnicalverification().onusParallelReferralProcessingBackbuttonisClickable();
		Assert.assertTrue(onusParallelReferralProcessingBackbuttonisClickable);
		System.out.println("Onus Parallel Referral Processing Back button is Clickable: "+onusParallelReferralProcessingBackbuttonisClickable);
		boolean onusParallelReferralProcessingAcceptbuttonisClickable = pom.getOnusTechnicalverification().onusParallelReferralProcessingAcceptbuttonisClickable();
		Assert.assertTrue(onusParallelReferralProcessingAcceptbuttonisClickable);
		System.out.println("Onus Parallel Referral Processing Accept button is Clickable: " + onusParallelReferralProcessingAcceptbuttonisClickable);
		boolean onusParallelReferralProcessingReturnbuttonisClickable = pom.getOnusTechnicalverification().onusParallelReferralProcessingReturnbuttonisClickable();
		Assert.assertTrue(onusParallelReferralProcessingReturnbuttonisClickable);
		System.out.println("Onus Parallel Referral Processing Return button is Clickable: "+onusParallelReferralProcessingReturnbuttonisClickable);
	}
	/**
     * @author ParasuramK Onus tech verification1 Arabic Field Verification
     */








	
	
	
	
	
	
	
	
	
	
	
	

}
