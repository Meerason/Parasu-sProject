package com.stepdefinition;

import java.awt.AWTException;

import org.junit.Assert;
import com.base.BaseClass;
import com.manager.PageObjectManager;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class InwardTechnicalVerifierStep extends BaseClass {
	PageObjectManager pom = new PageObjectManager();
	String inwardChequeNum;
	String inwardChequeAmount;
	String chequeStatus;
	String referralstepneed="Response awaiting from Referral Channel";
	
	/**
	 * @author parasuramk -Inward Regression Flow Methods =====Starting Here======
	 */
	@When("User is on Inward Technical Verifier1 {string}")
	public void user_is_on_inward_technical_verifier1(String batchNum) throws Exception {
		pom.getInwardTechnicalVerifier().inward(batchNum);
		Thread.sleep(3000);
		inwardChequeNum = pom.getInwardTechnicalVerifier().inwardChequeNum();
		System.out.println("Cheque Number: " + inwardChequeNum);
		inwardChequeAmount = pom.getInwardTechnicalVerifier().inwardChequeAmount();
		System.out.println("Cheque Amount:" + inwardChequeAmount);

	}
	@When("User return Cheque by maker")
	public void user_return_cheque_by_maker() throws Exception {
		pom.getInwardTechnicalVerifier().inwardReturn();
	}

	@When("Cheque with above the specified limit Login with Checker {string},{string}")
	public void cheque_with_above_the_specified_limit_login_with_checker(String chkuserName, String chkpassword) throws Exception {
		String chequeVal = inwardChequeAmount.replaceAll(",", "");
		double chequeValue = Double.parseDouble(chequeVal);
		if (chequeValue >= 10000) {
			pom.getLoginPage().logout();
			pom.getLoginPage().login(chkuserName, chkpassword);
			pom.getLoginPage().loginPopMsg();
			pom.getInwardTechnicalVerifier().inwardChecker(inwardChequeNum);
			pom.getInwardTechnicalVerifier().inwardReturnByChecker();
		}else {
			System.out.println("=================  No need Checker To Return  =================");
		}
	}
	
	@When("User accept Cheque by maker")
	public void user_accept_cheque_by_maker() throws InterruptedException, AWTException {
		pom.getInwardTechnicalVerifier().inwardAcceptByMaker();
	}
	@When("Cheque with above the specified limit Login with Checker and accept {string},{string}")
	public void cheque_with_above_the_specified_limit_login_with_checker_and_accept(String chkuserName, String chkpassword) throws InterruptedException, AWTException {
		String chequeVal = inwardChequeAmount.replaceAll(",", "");
		double chequeValue = Double.parseDouble(chequeVal);
		if (chequeValue >= 10000) {
			pom.getLoginPage().logout();
			pom.getLoginPage().login(chkuserName, chkpassword);
			pom.getLoginPage().loginPopMsg();
			pom.getInwardTechnicalVerifier().inwardChecker(inwardChequeNum);
			pom.getInwardTechnicalVerifier().inwardAcceptByChecker();
		}else {
			System.out.println("=================  No need Checker To Accept  =================");
		}
	}

	@Then("User verifying Cheque status")
	public void user_verifying_cheque_status() throws Exception {
		pom.getInwardTechnicalVerifier().search_ItemFinder(inwardChequeNum, inwardChequeAmount);
		Thread.sleep(1500);
		chequeStatus = pom.getInwardTechnicalVerifier().chequeStatus();
		System.out.println("Cheque Status:" + chequeStatus);
		if(chequeStatus==referralstepneed) {
			pom.getInwardTechnicalVerifier().inwardParallelReferralProcessingAccept(inwardChequeNum);
			pom.getInwardTechnicalVerifier().search_ItemFinder(inwardChequeNum, inwardChequeAmount);
			Thread.sleep(1500);
			chequeStatus = pom.getInwardTechnicalVerifier().chequeStatus();
			System.out.println("Cheque Status:" + chequeStatus);
		}
		
	}
	/**
	 * @author parasuramk -Inward Regression Flow Methods =========Ending Here=========
	 */

	
	
	/*** @author parasuramk -Inward field Verification Methods Starts here ***/
	
	@Then("User Verify Inward Technical Verifier1 Is Enabled")
	public void user_verify_inward_technical_verifier1_is_enabled() {
	    boolean inwardTechnicalVerifier1isClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1isClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1isClickable);
	    System.out.println("InwardTechnical Verifier1 is Clickable: " + inwardTechnicalVerifier1isClickable);
	}
	@Then("User Verify The Business Date Mandatory Field for Inward Technical Verifier1")
	public void user_verify_the_business_date_mandatory_field_for_inward_technical_verifier1() {
		boolean inwardTechnicalVerifier1BDisMandatory = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1BDisMandatory();
	    Assert.assertTrue(inwardTechnicalVerifier1BDisMandatory);
	    System.out.println("inward Technical Verifier1 Business Date is Mandatory: "+inwardTechnicalVerifier1BDisMandatory);
	    pom.getInwardTechnicalVerifier().acceptPopUpMsg();
	}
	@Then("User Verify Search button Is Enabled on Inward Technical Verifier1")
	public void user_verify_search_button_is_enabled_on_inward_technical_verifier1() {
	    boolean inwardTechnicalVerifier1SearchBtnisClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSearchBtnisClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1SearchBtnisClickable);
	    System.out.println("Inward Technical Verifier1 Search Btn is Clickable: " + inwardTechnicalVerifier1SearchBtnisClickable);
	}
	@When("User go to Inward Technical Verifier1 Batch details Page {string}")
	public void user_go_to_inward_technical_verifier1_batch_details_page(String batchNum) throws InterruptedException {
	    pom.getInwardTechnicalVerifier().goToInwardTechnicalVerifier1BatchDetailsPage(batchNum);
	    
	}
	@Then("User Verify Batch details Clickable on Inward Technical Verifier1")
	public void user_verify_batch_details_clickable_on_inward_technical_verifier1() {
		boolean inwardTechnicalVerifier1BatchDetailsareClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1BatchDetailsareClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1BatchDetailsareClickable);
	    System.out.println("Inward Technical Verifier1 Batch Details are Clickable: "+inwardTechnicalVerifier1BatchDetailsareClickable);
	    pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1BatchDetailClick();
	    
	}
	@Then("User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier1")
	public void user_verify_sigcap_verification_get_sigcapresult_override_btn_is_enabled_on_inward_technical_verifier1() {
	    boolean inwardTechnicalVerifier1SigCapVerificationClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSigCapVerificationClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1SigCapVerificationClickable);
	    System.out.println("Inward Technical Verifier1 SigCapVerification Btn Clickable: " + inwardTechnicalVerifier1SigCapVerificationClickable);
	    boolean inwardTechnicalVerifier1GetSigCapClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierGetSigCapClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1GetSigCapClickable);
	    System.out.println("Inward Technical Verifier1 GetSigCap Btn Clickable: " + inwardTechnicalVerifier1GetSigCapClickable);
	    boolean inwardTechnicalVerifier1OverrideClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierOverrideClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1OverrideClickable);
	    System.out.println("Inward Technical Verifier1 Override Btn Clickable: " + inwardTechnicalVerifier1OverrideClickable);
	    
	}
	@Then("User Verify Accept ,Return, return exception & skip button Is Enabled on Inward Technical Verifier1")
	public void user_verify_accept_return_return_exception_skip_button_is_enabled_on_inward_technical_verifier1() {
	   	boolean inwardTechnicalVerifier1AcceptBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierAcceptBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1AcceptBtnClickable);
	    System.out.println("Inward Technical Verifier1 Accept Btn Clickable: " + inwardTechnicalVerifier1AcceptBtnClickable);
	    boolean inwardTechnicalVerifier1ReturnBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ReturnBtnClickable);
	    System.out.println("Inward Technical Verifier1 Return Btn Clickable: " + inwardTechnicalVerifier1ReturnBtnClickable);
	    boolean inwardTechnicalVerifier1ReturnExceptionBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnExceptionBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ReturnExceptionBtnClickable);
	    System.out.println("Inward Technical Verifier1 Return Exception Btn Clickable: " + inwardTechnicalVerifier1ReturnExceptionBtnClickable);
	    boolean inwardTechnicalVerifier1SkipBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSkipBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1SkipBtnClickable);
	    System.out.println("Inward Technical Verifier1 Skip Btn Clickable: " + inwardTechnicalVerifier1SkipBtnClickable);
	    
	}
	/**
	 * @author ParasuramK inward Technical verifier 2
	 */
	@Then("User Verify Inward Technical Verifier2 Is Enabled")
	public void user_verify_inward_technical_verifier2_is_enabled() {
		boolean inwardTechnicalVerifier2isClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2isClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2isClickable);
	    System.out.println("Inward Technical Verifier2 is Clickable: " + inwardTechnicalVerifier2isClickable);
	}
	@Then("User Verify The Business Date Mandatory Field for Inward Technical Verifier2")
	public void user_verify_the_business_date_mandatory_field_for_inward_technical_verifier2() {
		boolean inwardTechnicalVerifier2BDisMandatory = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2BDisMandatory();
	    Assert.assertTrue(inwardTechnicalVerifier2BDisMandatory);
	    System.out.println("Inward Technical Verifier2 Business date is mandatory: " + inwardTechnicalVerifier2BDisMandatory);
	    pom.getInwardTechnicalVerifier().acceptPopUpMsg();
	}
	@Then("User Verify Search button Is Enabled on Inward Technical Verifier2")
	public void user_verify_search_button_is_enabled_on_inward_technical_verifier2() {
		 boolean inwardTechnicalVerifier2SearchBtnisClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSearchBtnisClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2SearchBtnisClickable);
		 System.out.println("Inward Technical Verifier2 Search btn Clickable: " + inwardTechnicalVerifier2SearchBtnisClickable);
	}
	@When("User go to Inward Technical Verifier2 Batch details Page {string}")
	public void user_go_to_inward_technical_verifier2_batch_details_page(String batchNum) throws InterruptedException {
		  pom.getInwardTechnicalVerifier().goToInwardTechnicalVerifier2BatchDetailsPage(batchNum);
	}
	@Then("User Verify Batch details Clickable on Inward Technical Verifier2")
	public void user_verify_batch_details_clickable_on_inward_technical_verifier2() {
		boolean inwardTechnicalVerifier2BatchDetailsareClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2BatchDetailsareClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2BatchDetailsareClickable);
	    System.out.println("Inward Technical Verifier2 BatchDetails Clickable: " + inwardTechnicalVerifier2BatchDetailsareClickable);
	    pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2BatchDetailClick();
	    
	}
	@Then("User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier2")
	public void user_verify_sigcap_verification_get_sigcapresult_override_btn_is_enabled_on_inward_technical_verifier2() {
		 boolean inwardTechnicalVerifier2SigCapVerificationClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSigCapVerificationClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2SigCapVerificationClickable);
		 System.out.println("Inward Technical Verifier2 SigCapVerification Btn Clickable: " + inwardTechnicalVerifier2SigCapVerificationClickable);
		 boolean inwardTechnicalVerifier2GetSigCapClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierGetSigCapClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2GetSigCapClickable);
		 System.out.println("Inward Technical Verifier2 GetSigCap Btn Clickable: " + inwardTechnicalVerifier2GetSigCapClickable);
		 boolean inwardTechnicalVerifier2OverrideClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierOverrideClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2OverrideClickable);
		 System.out.println("Inward Technical Verifier2 Override Btn Clickable: " + inwardTechnicalVerifier2OverrideClickable);
	}
	@Then("User Verify Accept ,Return, Return Exception,Send Back & Skip button Is Enabled on Inward Technical Verifier2")
	public void user_verify_accept_return_return_exception_send_back_skip_button_is_enabled_on_inward_technical_verifier2() {
		boolean inwardTechnicalVerifier2AcceptBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierAcceptBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2AcceptBtnClickable);
	    System.out.println("Inward Technical Verifier2 Accept Btn Clickable: " + inwardTechnicalVerifier2AcceptBtnClickable);
	    boolean inwardTechnicalVerifier2ReturnBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ReturnBtnClickable);
	    System.out.println("Inward Technical Verifier2 Return Btn Clickable: " + inwardTechnicalVerifier2ReturnBtnClickable);
	    boolean inwardTechnicalVerifier2ReturnExceptionBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnExceptionBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ReturnExceptionBtnClickable);
	    System.out.println("Inward Technical Verifier2 Return Exception Btn Clickable: " + inwardTechnicalVerifier2ReturnExceptionBtnClickable);
	    boolean inwardTechnicalVerifier2SkipBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSkipBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2SkipBtnClickable);
	    System.out.println("Inward Technical Verifier2 Skip Btn Clickable: " + inwardTechnicalVerifier2SkipBtnClickable);
	    boolean inwardTechnicalVerifier2SendBackBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSendBackBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2SendBackBtnClickable);
	    System.out.println("Inward Technical Verifier2 Send Back Btn Clickable: " + inwardTechnicalVerifier2SendBackBtnClickable);
	}
	/**
	 * @author ParasuramK inward Dashboard
	 */
	
	@Then("User Verify Inward Dashboard is Enabled")
	public void user_verify_inward_dashboard_is_enabled() {
	    boolean inwardDashboardisClickable = pom.getInwardTechnicalVerifier().inwardDashboardisClickable();
	    Assert.assertTrue(inwardDashboardisClickable);
	    System.out.println("Inward Dashboard is Clickable: " + inwardDashboardisClickable);
	    pom.getInwardTechnicalVerifier().inwardDashboard();
	}
	@Then("User Verify Inward Parsing- plus icon is Enabled on Inward Dashboard")
	public void user_verify_inward_parsing_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconInwardParsing().isEnabled();
	    Assert.assertTrue(enabled);
	    System.out.println("Inward Dashboard Inward Parsing Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify QR Code Validation- plus icon is Enabled on Inward Dashboard")
	public void user_verify_qr_code_validation_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconQRCodeValidation().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard QR Code Validation Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify OCR Service- plus icon is Enabled on Inward Dashboard")
	public void user_verify_ocr_service_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconOCRService().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard OCR Service Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify DSA Validation- plus icon is Enabled on Inward Dashboard")
	public void user_verify_dsa_validation_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconDSAValidation().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard DSA Validation Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify ASV Status- plus icon is Enabled on Inward Dashboard")
	public void user_verify_asv_status_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconASVStatus().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard ASV Status Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify ICR Service- plus icon is Enabled on Inward Dashboard")
	public void user_verify_icr_service_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconICRService().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard ICR Service Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify Technical Verification1 \\(OPC)- plus icon is Enabled on Inward Dashboard")
	public void user_verify_technical_verification1_opc_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconTechnicalVerification1().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard Technical verification1 Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify OPC Technical Verification2 \\(OPC)- plus icon is Enabled on Inward Dashboard")
	public void user_verify_opc_technical_verification2_opc_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconTechnicalVerification2().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard Technical verification2 Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify Referral Branch Referral Crad- plus icon is Enabled on Inward Dashboard")
	public void user_verify_referral_branch_referral_crad_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconReferralBranchReferralCrad().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard Referral/Branch referral/Crad Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify Posting to Finacle- plus icon is Enabled on Inward Dashboard")
	public void user_verify_posting_to_finacle_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconPostingtoFinacle().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard Posting to Finacle Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify Active CR- plus icon is Enabled on Inward Dashboard")
	public void user_verify_active_cr_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconActiveCR().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard Active CR Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify RCE File Creation- plus icon is Enabled on Inward Dashboard")
	public void user_verify_rce_file_creation_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconRCEFileCreation().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard RCE File Creation Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify RAK File Parsing- plus icon is Enabled on Inward Dashboard")
	public void user_verify_rak_file_parsing_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconRAKFileParsing().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard RAK File Parsing Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify NACK Reject Reprocessing- plus icon is Enabled on Inward Dashboard")
	public void user_verify_nack_reject_reprocessing_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconNACKRejectReprocessing().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard NACK Reject Reprocessing Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify Finacle- plus icon is Enabled on Inward Dashboard")
	public void user_verify_finacle_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconFinacle().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard Finacle Plus Icon is Clickable: " + enabled);
	}
	@Then("User Verify Awaiting- plus icon is Enabled on Inward Dashboard")
	public void user_verify_awaiting_plus_icon_is_enabled_on_inward_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getPlusIconAwaiting().isEnabled();
		Assert.assertTrue(enabled);
		System.out.println("Inward Dashboard Awaiting Plus Icon is Clickable: " + enabled);
	}
	/**
	 * @author ParasuramK Inward Search/Item Finder fields verification
	 */

	@Then("User Verify Inward Search\\/Item Finder is Enabled on Inward Dashboard")
	public void user_verify_inward_search_item_finder_is_enabled_on_inward_dashboard() {
	    boolean inwardSearchItemFinderisClickable = pom.getInwardTechnicalVerifier().inwardSearchItemFinderisClickable();
	    Assert.assertTrue(inwardSearchItemFinderisClickable);
	    System.out.println("Inward Search/ItemFinder is Clickable: "+inwardSearchItemFinderisClickable);
	    pom.getInwardTechnicalVerifier().inwardSearchItemFinder();
	}
	@Then("User Verify Search button Is Enabled on Inward Search\\/Item Finder")
	public void user_verify_search_button_is_enabled_on_inward_search_item_finder() {
		boolean enabled = pom.getInwardTechnicalVerifier().getBtnSearch().isEnabled();
		Assert.assertTrue(enabled);
	    System.out.println("Inward Search/ItemFinder Search button is Clickable: "+ enabled);
	}
	/**
	 * @author ParasuramK Inward Bank Wise Summary Dashboard fields verification
	 * @throws InterruptedException 
	 */
	@Then("User Verify Inward Bank Wise Summary Dashboard Option is clickable")
	public void user_verify_inward_bank_wise_summary_dashboard_option_is_clickable() throws InterruptedException {
	    boolean inwardBankWiseSummaryDashboardisClickable = pom.getInwardTechnicalVerifier().inwardBankWiseSummaryDashboardisClickable();
	    Assert.assertTrue(inwardBankWiseSummaryDashboardisClickable);
	    System.out.println("Inward Bank Wise Summary Dashboard is Clickable: " + inwardBankWiseSummaryDashboardisClickable);
	    pom.getInwardTechnicalVerifier().inwardBankWiseSummaryDashboard();
	}
	@Then("User Verify Refresh button is Enabled on Inward Bank Wise Summary Dashboard")
	public void user_verify_refresh_button_is_enabled_on_inward_bank_wise_summary_dashboard() {
	    boolean enabled = pom.getInwardTechnicalVerifier().getBtnRefresh().isEnabled();
	    System.out.println("Inward Bank Wise Summary Dashboard Refresh Button Is Clickable: " + enabled);
	}

	/**
	 * @author ParasuramK Inward Central Bank Status Dashboard fields verification
	 * @throws InterruptedException 
	 */
	
	@Then("User Verify Inward Central Bank Status Dashboard Option is clickable")
	public void user_verify_inward_central_bank_status_dashboard_option_is_clickable() throws InterruptedException {
		boolean inwardCentralBankStatusDashboardisClickable = pom.getInwardTechnicalVerifier().inwardCentralBankStatusDashboardisClickable();
		Assert.assertTrue(inwardCentralBankStatusDashboardisClickable);
		System.out.println("Inward Central Bank Status Dashboard menu Is Clickable: " + inwardCentralBankStatusDashboardisClickable);
		pom.getInwardTechnicalVerifier().inwardCentralBankStatusDashboard();
	}
	@Then("User Verify Refresh button is Enabled on Inward Central Bank Status Dashboard")
	public void user_verify_refresh_button_is_enabled_on_inward_central_bank_status_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getBtnRefresh().isEnabled();
	    System.out.println("Inward Central Bank Status Dashboard Refresh Button Is Clickable: " + enabled);
	}

	/**
	 * @author ParasuramK Inward Finacle Dashboard fields verification
	 * @throws InterruptedException 
	 */

	@Then("User Verify Inward Finacle Dashboard Option is clickable")
	public void user_verify_inward_finacle_dashboard_option_is_clickable() throws InterruptedException {
		boolean inwardFinacleDashboardisClickable = pom.getInwardTechnicalVerifier().inwardFinacleDashboardisClickable();
		Assert.assertTrue(inwardFinacleDashboardisClickable);
		System.out.println("Inward Finacle Dashboard menu Is Clickable: " + inwardFinacleDashboardisClickable);
		pom.getInwardTechnicalVerifier().inwardFinacleDashboard();
	}
	@Then("User Verify Refresh button is Enabled on Inward Finacle Dashboard")
	public void user_verify_refresh_button_is_enabled_on_inward_finacle_dashboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getBtnRefresh().isEnabled();
	    System.out.println("Inward Finacle Dashboard Refresh Button Is Clickable: " + enabled);
	}
	
	/**
	 * @author ParasuramK Inward Referral Dashboard fields verification
	 * @throws InterruptedException 
	 */

	@Then("User Verify Inward Referral Dashboard Option is clickable")
	public void user_verify_inward_referral_dashboard_option_is_clickable() throws InterruptedException {
		boolean inwardReferralDashboardisClickable = pom.getInwardTechnicalVerifier().inwardReferralDashboardisClickable();
		Assert.assertTrue(inwardReferralDashboardisClickable);
		System.out.println("Inward Referral Dashboard menu Is Clickable: " + inwardReferralDashboardisClickable);
		pom.getInwardTechnicalVerifier().inwardReferralDashboard();
	}
	@Then("User Verify Refresh button is Enabled on Inward Referral Dasboard")
	public void user_verify_refresh_button_is_enabled_on_inward_referral_dasboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getBtnRefresh().isEnabled();
	    System.out.println("Inward Referral Dashboard Refresh Button Is Clickable: " + enabled);
	}

	/**
	 * @author ParasuramK Inward Userwise Dashboard fields verification
	 * @throws InterruptedException 
	 */


	@Then("User Verify Inward Userwise Dashboard Option is clickable")
	public void user_verify_inward_userwise_dashboard_option_is_clickable() throws InterruptedException {
		boolean inwardUserwiseDashboardisClickable = pom.getInwardTechnicalVerifier().inwardUserwiseDashboardisClickable();
		Assert.assertTrue(inwardUserwiseDashboardisClickable);
		System.out.println("Inward Userwise Dashboard menu Is Clickable: " + inwardUserwiseDashboardisClickable);
		pom.getInwardTechnicalVerifier().inwardUserwiseDashboard();
	}
	@Then("User Verify Refresh button is Enabled on Inward Userwise Dasboard")
	public void user_verify_refresh_button_is_enabled_on_inward_userwise_dasboard() {
		boolean enabled = pom.getInwardTechnicalVerifier().getBtnRefresh().isEnabled();
	    System.out.println("Inward Userwise Dashboard Refresh Button Is Clickable: " + enabled);
	}

	/**
	 * @author ParasuramK Consolidated Posting Inward fields verification
	 */
	
	@Then("User Verify Consolidated Posting Inward Option is clickable")
	public void user_verify_consolidated_posting_inward_option_is_clickable() {
		 boolean consolidatedPostingInwardisClickable = pom.getInwardTechnicalVerifier().consolidatedPostingInwardisClickable();
		 Assert.assertTrue(consolidatedPostingInwardisClickable);
		 System.out.println("Consolidated Posting Inward menu Is Clickable: " + consolidatedPostingInwardisClickable);
		 pom.getInwardTechnicalVerifier().consolidatedPostingInward();
	}
	/**
	 * @author ParasuramK Inward Technical Verifier1 Arabic fields verification
	 */

	@Then("User Verify Inward Technical Verifier1 Arabic Option Is Enabled")
	public void user_verify_inward_technical_verifier1_arabic_option_is_enabled() {
		boolean inwardTechnicalVerifier1ArabicisClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1ArabicisClickable();
		Assert.assertTrue(inwardTechnicalVerifier1ArabicisClickable);
		System.out.println("Inward Technical Verifier 1 Arabic is Clickable: " + inwardTechnicalVerifier1ArabicisClickable);
		pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1Arabic();
	}
	@Then("User Verify The Business Date Mandatory Field for Inward Technical Verifier1 Arabic")
	public void user_verify_the_business_date_mandatory_field_for_inward_technical_verifier1_arabic() {
		boolean inwardTechnicalVerifierArabicBDisMandatory = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierArabicBDisMandatory();
		Assert.assertTrue(inwardTechnicalVerifierArabicBDisMandatory);
		System.out.println("Inward Technical Verifier 1 Arabic Business Date is Mandatory Msg PopUp: " + inwardTechnicalVerifierArabicBDisMandatory);
		pom.getInwardTechnicalVerifier().acceptPopUpMsg();
	}
	@Then("User Verify Search button Is Enabled on Inward Technical Verifier1 Arabic")
	public void user_verify_search_button_is_enabled_on_inward_technical_verifier1_arabic() {
		boolean inwardTechnicalVerifierArabicSearchBtnisClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierArabicSearchBtnisClickable();
		Assert.assertTrue(inwardTechnicalVerifierArabicSearchBtnisClickable);
		System.out.println("Inward Technical Verifier Arabic Search Btn is Clickable" + inwardTechnicalVerifierArabicSearchBtnisClickable);
	}
	@When("User go to Inward Technical Verifier1 Arabic Batch details Page {string}")
	public void user_go_to_inward_technical_verifier1_arabic_batch_details_page(String batchNum) throws InterruptedException {
		pom.getInwardTechnicalVerifier().goToInwardTechnicalVerifierArabicBatchDetailsPage(batchNum);
		
	}
	@Then("User Verify Batch details are Clickable on Inward Technical Verifier1 Arabic")
	public void user_verify_batch_details_are_clickable_on_inward_technical_verifier1_arabic() {
		boolean inwardTechnicalVerifier1ArabicBatchDetailsareClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1BatchDetailsareClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicBatchDetailsareClickable);
	    System.out.println("Inward Technical Verifier1 Arabic Batch Details are Clickable: "+inwardTechnicalVerifier1ArabicBatchDetailsareClickable);
	    pom.getInwardTechnicalVerifier().inwardTechnicalVerifier1BatchDetailClick();
	}
	@Then("User verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier1 Arabic")
	public void user_verify_sigcap_verification_get_sigcapresult_override_btn_is_enabled_on_inward_technical_verifier1_arabic() {
		boolean inwardTechnicalVerifier1ArabicSigCapVerificationClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSigCapVerificationClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicSigCapVerificationClickable);
	    System.out.println("Inward Technical Verifier1 Arabic SigCapVerification Btn Clickable: " + inwardTechnicalVerifier1ArabicSigCapVerificationClickable);
	    boolean inwardTechnicalVerifier1ArabicGetSigCapClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierGetSigCapClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicGetSigCapClickable);
	    System.out.println("Inward Technical Verifier1 Arabic GetSigCap Btn Clickable: " + inwardTechnicalVerifier1ArabicGetSigCapClickable);
	    boolean inwardTechnicalVerifier1ArabicOverrideClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierOverrideClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicOverrideClickable);
	    System.out.println("Inward Technical Verifier1 Arabic Override Btn Clickable: " + inwardTechnicalVerifier1ArabicOverrideClickable);
	}

	@Then("User Verify Accept ,Return, Return Exception & Skip button Is Enabled on Inward Technical Verifier1 Arabic")
	public void user_verify_accept_return_return_exception_skip_button_is_enabled_on_inward_technical_verifier1_arabic() {
		boolean inwardTechnicalVerifier1ArabicAcceptBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierAcceptBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicAcceptBtnClickable);
	    System.out.println("Inward Technical Verifier1 Arabic Accept Btn Clickable: " + inwardTechnicalVerifier1ArabicAcceptBtnClickable);
	    boolean inwardTechnicalVerifier1ArabicReturnBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicReturnBtnClickable);
	    System.out.println("Inward Technical Verifier1 Arabic Return Btn Clickable: " + inwardTechnicalVerifier1ArabicReturnBtnClickable);
	    boolean inwardTechnicalVerifier1ArabicReturnExceptionBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnExceptionBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicReturnExceptionBtnClickable);
	    System.out.println("Inward Technical Verifier1 Arabic Return Exception Btn Clickable: " + inwardTechnicalVerifier1ArabicReturnExceptionBtnClickable);
	    boolean inwardTechnicalVerifier1ArabicSkipBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSkipBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier1ArabicSkipBtnClickable);
	    System.out.println("Inward Technical Verifier1 Arabic Skip Btn Clickable: " + inwardTechnicalVerifier1ArabicSkipBtnClickable);
	}
	
	/**
	 * @author ParasuramK Inward Technical Verifier 2 Arabic fields verification
	 */
	
	@Then("User Verify Inward Technical Verifier2 Arabic Option Is Enabled")
	public void user_verify_inward_technical_verifier2_arabic_option_is_enabled() {
		boolean inwardTechnicalVerifier2ArabicisClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2ArabicisClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicisClickable);
	    System.out.println("Inward Technical Verifier2 Arabic is Clickable: " + inwardTechnicalVerifier2ArabicisClickable);
	}
	@Then("User Verify The Business Date Mandatory Field for Inward Technical Verifier2 Arabic")
	public void user_verify_the_business_date_mandatory_field_for_inward_technical_verifier2_arabic() {
		boolean inwardTechnicalVerifier2ArabicBDisMandatory = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2ArabicBDisMandatory();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicBDisMandatory);
	    System.out.println("Inward Technical Verifier2 Arabic Business date is mandatory: " + inwardTechnicalVerifier2ArabicBDisMandatory);
	    pom.getInwardTechnicalVerifier().acceptPopUpMsg();
	}
	@Then("User Verify Search button Is Enabled on Inward Technical Verifier2 Arabic")
	public void user_verify_search_button_is_enabled_on_inward_technical_verifier2_arabic() {
		boolean inwardTechnicalVerifier2ArabicSearchBtnisClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSearchBtnisClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2ArabicSearchBtnisClickable);
		 System.out.println("Inward Technical Verifier2 Arabic Search btn Clickable: " + inwardTechnicalVerifier2ArabicSearchBtnisClickable);
	}
	@When("User go to Inward Technical Verifier2 Arabic Batch details Page {string}")
	public void user_go_to_inward_technical_verifier2_arabic_batch_details_page(String batchNum) throws InterruptedException {
		 pom.getInwardTechnicalVerifier().goToInwardTechnicalVerifier2ArabicBatchDetailsPage(batchNum);
	}
	@Then("User Verify Batch details are Clickable on Inward Technical Verifier2 Arabic")
	public void user_verify_batch_details_are_clickable_on_inward_technical_verifier2_arabic() {
		boolean inwardTechnicalVerifier2ArabicBatchDetailsareClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2ArabicBatchDetailsareClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicBatchDetailsareClickable);
	    System.out.println("Inward Technical Verifier2 Arabic BatchDetails Clickable: " + inwardTechnicalVerifier2ArabicBatchDetailsareClickable);
	    pom.getInwardTechnicalVerifier().inwardTechnicalVerifier2ArabicBatchDetailClick();
	}
	@Then("User verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier2 Arabic")
	public void user_verify_sigcap_verification_get_sigcapresult_override_btn_is_enabled_on_inward_technical_verifier2_arabic() {
		boolean inwardTechnicalVerifier2ArabicSigCapVerificationClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSigCapVerificationClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2ArabicSigCapVerificationClickable);
		 System.out.println("Inward Technical Verifier2 Atabic SigCapVerification Btn Clickable: " + inwardTechnicalVerifier2ArabicSigCapVerificationClickable);
		 boolean inwardTechnicalVerifier2ArabicGetSigCapClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierGetSigCapClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2ArabicGetSigCapClickable);
		 System.out.println("Inward Technical Verifier2 Arabic GetSigCap Btn Clickable: " + inwardTechnicalVerifier2ArabicGetSigCapClickable);
		 boolean inwardTechnicalVerifier2ArabicOverrideClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierOverrideClickable();
		 Assert.assertTrue(inwardTechnicalVerifier2ArabicOverrideClickable);
		 System.out.println("Inward Technical Verifier2 Arabic Override Btn Clickable: " + inwardTechnicalVerifier2ArabicOverrideClickable);
	}
	@Then("User verify Accept ,Return, Return Exception, Send back & Skip button Is Enabled on Inward Technical Verifier2 Arabic")
	public void user_verify_accept_return_return_exception_send_back_skip_button_is_enabled_on_inward_technical_verifier2_arabic() {
		boolean inwardTechnicalVerifier2ArabicAcceptBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierAcceptBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicAcceptBtnClickable);
	    System.out.println("Inward Technical Verifier2 Arabic Accept Btn Clickable: " + inwardTechnicalVerifier2ArabicAcceptBtnClickable);
	    boolean inwardTechnicalVerifier2ArabicReturnBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicReturnBtnClickable);
	    System.out.println("Inward Technical Verifier2 Arabic Return Btn Clickable: " + inwardTechnicalVerifier2ArabicReturnBtnClickable);
	    boolean inwardTechnicalVerifier2ArabicReturnExceptionBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierReturnExceptionBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicReturnExceptionBtnClickable);
	    System.out.println("Inward Technical Verifier2 Arabic Return Exception Btn Clickable: " + inwardTechnicalVerifier2ArabicReturnExceptionBtnClickable);
	    boolean inwardTechnicalVerifier2ArabicSkipBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSkipBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicSkipBtnClickable);
	    System.out.println("Inward Technical Verifier2 Arabic Skip Btn Clickable: " + inwardTechnicalVerifier2ArabicSkipBtnClickable);
	    boolean inwardTechnicalVerifier2ArabicSendBackBtnClickable = pom.getInwardTechnicalVerifier().inwardTechnicalVerifierSendBackBtnClickable();
	    Assert.assertTrue(inwardTechnicalVerifier2ArabicSendBackBtnClickable);
	    System.out.println("Inward Technical Verifier2 Arabic Send Back Btn Clickable: " + inwardTechnicalVerifier2ArabicSendBackBtnClickable);
	}

	/**
	 * @author ParasuramK Inward Reject Repair Maker fields verification
	 */
	
	@Then("User Verify Inward Reject Repair Maker Is Enabled")
	public void user_verify_inward_reject_repair_maker_is_enabled() {
		boolean rejectRepairMakerisClickable = pom.getInwardTechnicalVerifier().rejectRepairMakerisClickable();
		Assert.assertTrue(rejectRepairMakerisClickable);
		System.out.println("Reject Repair Maker is Clickable: "+ rejectRepairMakerisClickable);
		pom.getInwardTechnicalVerifier().rejectRepairMaker();
	}
	@Then("User Verify The Business Date Mandatory Field for Inward Reject Repair Maker")
	public void user_verify_the_business_date_mandatory_field_for_inward_reject_repair_maker() {
		boolean rejectRepairMakerBDisMandatory = pom.getInwardTechnicalVerifier().rejectRepairMakerBDisMandatory();
		Assert.assertTrue(rejectRepairMakerBDisMandatory);
		System.out.println("Reject Repair Maker Business Date is Mandatory: " + rejectRepairMakerBDisMandatory);
		pom.getInwardTechnicalVerifier().acceptPopUpMsg();
	}
	@Then("User Verify Search button Is Enabled on Inward Reject Repair Maker")
	public void user_verify_search_button_is_enabled_on_inward_reject_repair_maker() {
		boolean rejectRepairMakerSearchBtnisClickable = pom.getInwardTechnicalVerifier().rejectRepairMakerSearchBtnisClickable();
		Assert.assertTrue(rejectRepairMakerSearchBtnisClickable);
		System.out.println("Reject Repair Maker Search Button is Clickable: "+rejectRepairMakerSearchBtnisClickable);
	}

	/**
	 * @author ParasuramK Inward Reject Repair Maker Arabic fields verification
	 */
	@Then("User Verify Reject Repair Maker Arabic Is Enabled")
	public void user_verify_reject_repair_maker_arabic_is_enabled() {
		boolean rejectRepairMakerArabicisClickable = pom.getInwardTechnicalVerifier().rejectRepairMakerArabicisClickable();
		Assert.assertTrue(rejectRepairMakerArabicisClickable);
		System.out.println("Reject Repair Maker Arabic is Clickable: "+ rejectRepairMakerArabicisClickable);
		pom.getInwardTechnicalVerifier().rejectRepairMakerArabic();
	}
	@Then("User Verify The Business Date Mandatory Field for Reject Repair Maker Arabic")
	public void user_verify_the_business_date_mandatory_field_for_reject_repair_maker_arabic() {
		boolean rejectRepairMakerArabicBDisMandatory = pom.getInwardTechnicalVerifier().rejectRepairMakerBDisMandatory();
		Assert.assertTrue(rejectRepairMakerArabicBDisMandatory);
		System.out.println("Reject Repair Maker Arabic Business Date is Mandatory: " + rejectRepairMakerArabicBDisMandatory);
		pom.getInwardTechnicalVerifier().acceptPopUpMsg();
	}
	@Then("User Verify Search button Is Enabled on Reject Repair Maker Arabic")
	public void user_verify_search_button_is_enabled_on_reject_repair_maker_arabic() {
		boolean rejectRepairMakerArabicSearchBtnisClickable = pom.getInwardTechnicalVerifier().rejectRepairMakerSearchBtnisClickable();
		Assert.assertTrue(rejectRepairMakerArabicSearchBtnisClickable);
		System.out.println("Reject Repair Maker Arabic Search Button is Clickable: "+rejectRepairMakerArabicSearchBtnisClickable);
	}
	/**
	 * @author ParasuramK Inward Branch Referral Crad fields verification
	 */
	
	@Then("User Verify Inward Branch Referral Crad Option Is Enabled")
	public void user_verify_inward_branch_referral_crad_option_is_enabled() {
		boolean inwardBranchReferralCradisClickable = pom.getInwardTechnicalVerifier().inwardBranchReferralCradisClickable();
		Assert.assertTrue(inwardBranchReferralCradisClickable);
		System.out.println("Inward Branch Referral Crad is Clickable: "+ inwardBranchReferralCradisClickable);
		pom.getInwardTechnicalVerifier().rejectRepairMakerArabic();
	}
	@Then("User Verify The Business Date Mandatory Field for Branch Referral Crad")
	public void user_verify_the_business_date_mandatory_field_for_branch_referral_crad() {
		boolean inwardBranchReferralCradBDisMandatory = pom.getInwardTechnicalVerifier().rejectRepairMakerBDisMandatory();
		Assert.assertTrue(inwardBranchReferralCradBDisMandatory);
		System.out.println("Inward Branch Referral Crad Business Date is Mandatory: " + inwardBranchReferralCradBDisMandatory);
		pom.getInwardTechnicalVerifier().acceptPopUpMsg();
	}
	@Then("User Verify Search button Is Enabled on Branch Referral Crad")
	public void user_verify_search_button_is_enabled_on_branch_referral_crad() {
		boolean inwardBranchReferralCradSearchBtnisClickable = pom.getInwardTechnicalVerifier().rejectRepairMakerSearchBtnisClickable();
		Assert.assertTrue(inwardBranchReferralCradSearchBtnisClickable);
		System.out.println("Inward Branch Referral Crad Search Button is Clickable: "+inwardBranchReferralCradSearchBtnisClickable);
	}











		
	
	



}
