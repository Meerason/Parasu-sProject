package com.stepdefinition;


import org.junit.Assert;
import org.openqa.selenium.WebElement;
import com.base.BaseClass;
import com.manager.PageObjectManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class LoginPageStep extends BaseClass {
	PageObjectManager pom = new PageObjectManager();
	
	@Given("User is on the ExpressClear LoginPage")
	public void user_is_on_the_express_clear_login_page() throws Exception {
	System.out.println("===================    Started    ===================");
	}

	@When("User perform login {string},{string}")
	public void user_perform_login(String userName, String password) throws Exception {
		pom.getLoginPage().login(userName, password);
	}

	@Then("User should verify after login success message {string}")
	public void user_should_verify_after_login_success_message(String expSuccessMsg) throws InterruptedException {
		WebElement successMsg = pom.getLoginPage().getSuccessMsgPopUp();
		String actSuccessMsg = elementGetText(successMsg);
		System.out.println(actSuccessMsg);
		Assert.assertEquals(expSuccessMsg, actSuccessMsg);
		pom.getLoginPage().loginPopMsg();

	}
	@Then("User should verify after login Failed message {string}")
	public void user_should_verify_after_login_failed_message(String expFailedMsg) {
	   WebElement failedMsg = pom.getLoginPage().getFailedMsg();
	   String FailedMsgstring = elementGetText(failedMsg);
	   String actFailedMsg = FailedMsgstring.substring(42, FailedMsgstring.length());
	   System.out.println(actFailedMsg);
	   Assert.assertEquals(actFailedMsg, expFailedMsg);
	}

	@When("User perform login without credentials")
	public void user_perform_login_without_credentials() {
		WebElement btnLogin = pom.getLoginPage().getBtnLogin();
		elementClick(btnLogin);
	}
}
