package com.report;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.base.BaseClass;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class Reporting extends BaseClass {
	/**
	 * @see used to generate JVM report
	 * @param json
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void generateJVMReport(String json) throws FileNotFoundException, IOException {
		File file = new File(getProjectPath()+getPropertyFileValue("jvmPath"));

		Configuration configuration = new Configuration(file, "ExpressClear");
		configuration.addClassifications("Application", "ExpressClear");
		configuration.addClassifications("Environment", "Testing");
		configuration.addClassifications("Suite", "Regression");
		configuration.addClassifications("browser", "Chrome");
		configuration.addClassifications("browser version", "121.0.6167.140");

		List<String> jsonFiles = new ArrayList<String>();
		jsonFiles.add(json);
		ReportBuilder builder = new ReportBuilder(jsonFiles, configuration);
		builder.generateReports();

	}
}
