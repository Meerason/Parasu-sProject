package com.manager;

import com.pages.InwardTechnicalVerifier;
import com.pages.LoginPage;
import com.pages.OnusTechnicalVerification;

public class PageObjectManager {
			
		private LoginPage loginPage;
		private InwardTechnicalVerifier inwardTechnicalVerifier;
		private OnusTechnicalVerification onusTechnicalverification;
			
		public InwardTechnicalVerifier getInwardTechnicalVerifier() {
			return (inwardTechnicalVerifier==null)?inwardTechnicalVerifier=new InwardTechnicalVerifier():inwardTechnicalVerifier;
		}

		public LoginPage getLoginPage() {
			return (loginPage==null)?loginPage=new LoginPage():loginPage;
		}

		public OnusTechnicalVerification getOnusTechnicalverification() {
			return (onusTechnicalverification==null)?onusTechnicalverification=new OnusTechnicalVerification():onusTechnicalverification;
		}
		
}
