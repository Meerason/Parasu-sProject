package com.runner;

import java.io.FileNotFoundException;
import java.io.IOException;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import com.base.BaseClass;
import com.report.Reporting;
import io.cucumber.junit.CucumberOptions;

import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(tags = ("@onusFieldVerification"), stepNotifications = false, 
plugin = {"pretty", "json:target/index.json"}, 
		dryRun = false, publish = true, monochrome = true, 
		features = "src/test/resources", glue = "com.stepdefinition")

public class TestRunnerClass extends BaseClass {

 
	
	@AfterClass
	public static void afterClass() throws FileNotFoundException, IOException {
		
		System.out.println(" ============ Report Generation Started ============ ");
		Reporting.generateJVMReport(getProjectPath() + getPropertyFileValue("jsonPath"));
		System.out.println(" ============ Report Generation Done ============ ");
		
	}
}



    





