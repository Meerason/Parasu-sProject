package com.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;

public class OnusTechnicalVerification extends BaseClass{
	
	public OnusTechnicalVerification() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//span[text()='Onus']")
	private WebElement onus;
	
	@FindBy(xpath = "//span[text()='Onus Process']")
	private WebElement onusProcess;
	
	@FindBy(xpath = "//span[text()='Onus Technical VerificationI']")
	private WebElement onusTechnicalVerificationI;
	
	@FindBy(xpath = "//span[text()='Onus Technical VerificationII']")
	private WebElement onusTechnicalVerificationII;
	
	@FindBy(xpath = "(//span[text()='Search/Item Finder'])[2]")
	private WebElement searchItemFinderdd;
	
	@FindBy(xpath = "(//span[text()='Search/Item Finder'])[3]")
	private WebElement searchItemFinderOption;
	
	@FindBy(xpath = "//span[text()='Outward & Onus']")
	private WebElement outwardAndOnus;
	
	@FindBy(xpath = "//span[text()='Business Date *']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement txtOnusV1BussinessDate;
	
	@FindBy(xpath = "//span[text()='Business Date*']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement txtOnusV2BussinessDate;
	
	@FindBy(xpath = "//div[@class='z-combobox-popup z-combobox-open z-combobox-shadow']/ul/li[1]")
	private WebElement todayV2BussinessDate;
	
	@FindBy(xpath = "//span[text()='Batch Number']/parent::div/parent::td/following-sibling::td/div/input")
	private WebElement txtOnusBatchNumber;
	
	@FindBy(xpath = "//span[text()='Cheque Number']/parent::div/parent::td/following-sibling::td/div/input")
	private WebElement txtOnusV2ChequeNum;
	
	@FindBy(xpath = "//span[text()='Process Type *']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement processTypedd;
	
	@FindBy(xpath = "//li/span[text()='Onus']")
	private WebElement OnusprocessTypedd;
	
	@FindBy(xpath = "//button[text()='Search']")
	private WebElement btnSearch;
	
	@FindBy(xpath = "//div[@class='z-listbox-body']/table/tbody/tr[1]/td[2]/div")
	private WebElement chequelist1stline;
	
	@FindBy(xpath = "(//div[@class='z-listcell-content'])[15]")
	private WebElement chequeStatus;
	
	@FindBy(xpath = "//button[text()='Return']")
	private WebElement btnReturn;

	@FindBy(xpath = "//button[text()='Accept']")
	private WebElement btnAccept;
	
	@FindBy(xpath = "//button[text()='Skip']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement returnReason;
	
	@FindBy(xpath = "/html/body/div[4]/ul/li[3]/span[2]")
	private WebElement optionMultilatedItem;
	
	@FindBy(xpath = "(//i[@class='z-icon-times z-tab-icon'])[1]")
	private WebElement tapCloseIcon;
	
	@FindBy(xpath = "//span[text()='Amount']/parent::td/parent::tr/following-sibling::tr[2]/td/input")
	private WebElement txtAmount;
		
	@FindBy(xpath = "//span[text()='Batch ID:']/parent::div//parent::td/following-sibling::td/div/span")
	private WebElement chequeBatchIDV1;
	
	@FindBy(xpath = "(//span[text()='MICR Code']/parent::td/parent::tr/parent::tbody/tr[3]/td/table/tbody/tr/td/table/tbody/tr/td/input)[1]")
	private WebElement chequeNumV1;
	
	@FindBy(xpath = "(//i[@class='z-borderlayout-icon z-icon-chevron-right'])[1]")
	private WebElement menuIcon;
	
	@FindBy(xpath = "//span[text()='Amount']/parent::div/parent::td/following-sibling::td/div/input")
	private WebElement txtAmountFieldItemFinder;
	
	@FindBy(xpath = "//span[text()='Physical Cheque validation']")
	private WebElement physicalChequeValidation;
	
	@FindBy(xpath = "//button[text()='Verify']/parent::div/parent::td/following-sibling::td/div/button")
	private WebElement btnDeletePhysicalchequeVali;
	
	@FindBy(xpath = "//button[text()='Delete']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement btnVerifyPhysicalchequeVali;
	
	@FindBy(xpath="//button[text()='OK']")
	private WebElement btnOK;
	
	@FindBy(xpath="//button[text()='Yes']")
	private WebElement btnYes;
	
	@FindBy(xpath = "//button[text()='Sigcap Verification']")
	private WebElement btnsigcapVerification;

	@FindBy(xpath = "//button[text()='Get Sigcap Result']")
	private WebElement btngetsigcapVerification;

	@FindBy(xpath = "//button[text()='Override']")
	private WebElement btnOverride;
	
	@FindBy(xpath = "//div[@class='z-window-icon z-window-close']")
	private WebElement btnsigcapClose;
	
	@FindBy(xpath="//div[@class='z-combobox-popup  z-combobox-open z-combobox-shadow']/ul/li[1]")
	private WebElement onusV1DateSelection;
	
	@FindBy(xpath="//span[text()='Onus Parallel Referral Processing']")
	private WebElement onusParallelReferralProcessing;
	
	@FindBy(xpath="//div[@class='z-listbox-body']/table/tbody/tr[1]/td[1]/div/span")
	private WebElement chequeList1stLineOnusReferral;
	
	@FindBy(xpath="//span[text()='Onus Branch Cheque Capture']")
	private WebElement onusBranchChequeCapture;
	@FindBy(xpath="//button[text()='Initialize']")
	private WebElement btnInitialize;
	@FindBy(xpath="//button[text()='Start']")
	private WebElement btnStart;
	@FindBy(xpath="//button[text()='Stop']")
	private WebElement btnStop;
	@FindBy(xpath="//button[text()='Finish']")
	private WebElement btnFinish;
	@FindBy(xpath="//span[text()='Presentation Type*']/parent::div/parent::td/following-sibling::td[1]/div/span/a")
	private WebElement ddIconPresentationType;
	@FindBy(xpath="//span[text()='NORMAL']")
	private WebElement ddNormalPresentationType;
	@FindBy(xpath="//span[text()='BULK']")
	private WebElement ddBulkPresentationType;
	@FindBy(xpath="//span[text()='Scanner Type*']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement ddIconScannerType;
	@FindBy(xpath="//span[text()='SMARTSOURCE']")
	private WebElement ddSmartsourceScannerType;
	@FindBy(xpath="//span[text()='CR190']")
	private WebElement ddCR190ScannerType;
	@FindBy(xpath="//span[text()='Please Select Presentation Type!']")
	private WebElement presentationTypeMandatoryMsg;
	@FindBy(xpath="//span[text()='Please Select Scanner!']")
	private WebElement scannerTypeMandatoryMsg;
	@FindBy(xpath="//button[text()='Proceed']")
	private WebElement btnProceed;
	
	@FindBy(xpath="//span[text()='Onus Branch Cheque Capture']/parent::a/parent::li/following-sibling::li/a/span[text()='Scan Verification']")
	private WebElement scanVerificationMenu;
	@FindBy(xpath="//span[text()='Please select business date !']")
	private WebElement businessDateisMandatoryMsg;
	@FindBy(xpath="//span[text()='Please enter business date !']")
	private WebElement enterBusinessDateisMandatoryMsg;
	
	@FindBy(xpath="//span[text()='Onus OPC Reject Repair Maker']")
	private WebElement onusOPCRejectRepairMakerMenu;
	
	@FindBy(xpath="//button[text()='Back']")
	private WebElement btnBack;
	@FindBy(xpath="//button[text()='Release Lock']")
	private WebElement btnReleaseLock;
	
	@FindBy(xpath="//button[text()='Release Lock']/parent::td/following-sibling::td/button[text()='Verify']")
	private WebElement btnVerifyOnBatchDetailsPhysicalCV;
	@FindBy(xpath="//button[text()='Release Lock']/parent::td/following-sibling::td/button[text()='Delete']")
	private WebElement btnDeleteOnBatchDetailsPhysicalCV;
	
	@FindBy(xpath="//span[text()='Checker Wise Verified Status']")
	private WebElement checkerWiseVerifiedStatusMenu;
	@FindBy(xpath="//button[text()='Refresh']")
	private WebElement btnRefresh;
	
	@FindBy(xpath="//span[text()='Maker Wise Processing Status']")
	private WebElement makerWiseProcessingStatusMenu;
	
	@FindBy(xpath="//span[text()='Onus ChannelWise Processing Status Dashboard']")
	private WebElement onusChannelWiseProcessingStatusDashboardMenu;
	@FindBy(xpath="//span[text()='Onus Finacle Dashboard']")
	private WebElement onusFinacleDashboardMenu;
	@FindBy(xpath="//span[text()='Onus Refferal Dashboard']")
	private WebElement onusRefferalDashboardMenu;
	@FindBy(xpath="//span[text()='Onus Branch Referral Crad']")
	private WebElement onusBranchReferralCradMenu;
	
	@FindBy(xpath="//span[text()='Onus Dashboard']")
	private WebElement onusDashboardMenu;
	@FindBy(xpath="//span[text()='Total Cheque Scanned']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconTotalChequeScanned;
	@FindBy(xpath="//span[text()='QR Code Validation']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconQRCodeValidation;
	@FindBy(xpath="//span[text()='ICR Service']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconICRService;
	@FindBy(xpath="//span[text()='Technical Verification I with Data Entry (OPC)']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconTechnicalVerificationI;
	@FindBy(xpath="//span[text()='Technical Verification II (OPC)']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconTechnicalVerificationII;
	@FindBy(xpath="//span[text()='Branch Referral Crad']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconBranchReferralCrad;
	@FindBy(xpath="//span[text()='Posting to Finacle']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconPostingtoFinacle;
	@FindBy(xpath="//span[text()='ACE File Creation']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconACEFileCreation;
	@FindBy(xpath="//span[text()='ACE ACK File Parsing']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconACEACKFileParsing;
	@FindBy(xpath="//span[text()='NACK Reject Reprocessing']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconNACKRejectReprocessing;
	@FindBy(xpath="//span[text()='Channel Wise cheque Status Count']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconChannelWisechequeStatusCount;
	@FindBy(xpath="//span[text()='Finacle']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconFinacle;
	@FindBy(xpath="//span[text()='Awaiting']/parent::div/parent::td/preceding-sibling::td/div/button")
	private WebElement onusDashboardPlusIconAwaiting;
	
	@FindBy(xpath="//span[text()='Onus OPC Arabic Reject Repair Maker']")
	private WebElement onusOPCArabicRejectRepairMakerMenu;
	
	@FindBy(xpath="//span[text()='Onus Parallel Referral Processing']")
	private WebElement onusParallelReferralProcessingMenu;
	
	
		
	public WebElement getOnusParallelReferralProcessingMenu() {
		return onusParallelReferralProcessingMenu;
	}

	public WebElement getBtnReleaseLock() {
		return btnReleaseLock;
	}

	public WebElement getOnusOPCArabicRejectRepairMakerMenu() {
		return onusOPCArabicRejectRepairMakerMenu;
	}

	public WebElement getOnusDashboardMenu() {
		return onusDashboardMenu;
	}

	public WebElement getOnusDashboardPlusIconTotalChequeScanned() {
		return onusDashboardPlusIconTotalChequeScanned;
	}

	public WebElement getOnusDashboardPlusIconQRCodeValidation() {
		return onusDashboardPlusIconQRCodeValidation;
	}

	public WebElement getOnusDashboardPlusIconICRService() {
		return onusDashboardPlusIconICRService;
	}

	public WebElement getOnusDashboardPlusIconTechnicalVerificationI() {
		return onusDashboardPlusIconTechnicalVerificationI;
	}

	public WebElement getOnusDashboardPlusIconTechnicalVerificationII() {
		return onusDashboardPlusIconTechnicalVerificationII;
	}

	public WebElement getOnusDashboardPlusIconBranchReferralCrad() {
		return onusDashboardPlusIconBranchReferralCrad;
	}

	public WebElement getOnusDashboardPlusIconPostingtoFinacle() {
		return onusDashboardPlusIconPostingtoFinacle;
	}

	public WebElement getOnusDashboardPlusIconACEFileCreation() {
		return onusDashboardPlusIconACEFileCreation;
	}

	public WebElement getOnusDashboardPlusIconACEACKFileParsing() {
		return onusDashboardPlusIconACEACKFileParsing;
	}

	public WebElement getOnusDashboardPlusIconNACKRejectReprocessing() {
		return onusDashboardPlusIconNACKRejectReprocessing;
	}

	public WebElement getOnusDashboardPlusIconChannelWisechequeStatusCount() {
		return onusDashboardPlusIconChannelWisechequeStatusCount;
	}

	public WebElement getOnusDashboardPlusIconFinacle() {
		return onusDashboardPlusIconFinacle;
	}

	public WebElement getOnusDashboardPlusIconAwaiting() {
		return onusDashboardPlusIconAwaiting;
	}

	public WebElement getOnusBranchReferralCradMenu() {
		return onusBranchReferralCradMenu;
	}

	public WebElement getOnusRefferalDashboardMenu() {
		return onusRefferalDashboardMenu;
	}

	public WebElement getOnusFinacleDashboardMenu() {
		return onusFinacleDashboardMenu;
	}

	public WebElement getOnusChannelWiseProcessingStatusDashboardMenu() {
		return onusChannelWiseProcessingStatusDashboardMenu;
	}

	public WebElement getMakerWiseProcessingStatusMenu() {
		return makerWiseProcessingStatusMenu;
	}

	public WebElement getCheckerWiseVerifiedStatusMenu() {
		return checkerWiseVerifiedStatusMenu;
	}

	public WebElement getBtnRefresh() {
		return btnRefresh;
	}

	public WebElement getBtnBack() {
		return btnBack;
	}

	public WebElement getBtnVerifyOnBatchDetailsPhysicalCV() {
		return btnVerifyOnBatchDetailsPhysicalCV;
	}

	public WebElement getBtnDeleteOnBatchDetailsPhysicalCV() {
		return btnDeleteOnBatchDetailsPhysicalCV;
	}
	
	public WebElement getEnterBusinessDateisMandatoryMsg() {
		return enterBusinessDateisMandatoryMsg;
	}

	public WebElement getOnusOPCRejectRepairMakerMenu() {
		return onusOPCRejectRepairMakerMenu;
	}

	public WebElement getBusinessDateisMandatoryMsg() {
		return businessDateisMandatoryMsg;
	}

	public WebElement getScanVerificationMenu() {
		return scanVerificationMenu;
	}

	public WebElement getBtnProceed() {
		return btnProceed;
	}

	public WebElement getOnusBranchChequeCapture() {
		return onusBranchChequeCapture;
	}

	public WebElement getBtnInitialize() {
		return btnInitialize;
	}

	public WebElement getBtnStart() {
		return btnStart;
	}

	public WebElement getBtnStop() {
		return btnStop;
	}

	public WebElement getBtnFinish() {
		return btnFinish;
	}

	public WebElement getDdIconPresentationType() {
		return ddIconPresentationType;
	}

	public WebElement getDdNormalPresentationType() {
		return ddNormalPresentationType;
	}

	public WebElement getDdBulkPresentationType() {
		return ddBulkPresentationType;
	}

	public WebElement getDdIconScannerType() {
		return ddIconScannerType;
	}

	public WebElement getDdSmartsourceScannerType() {
		return ddSmartsourceScannerType;
	}

	public WebElement getDdCR190ScannerType() {
		return ddCR190ScannerType;
	}

	public WebElement getPresentationTypeMandatoryMsg() {
		return presentationTypeMandatoryMsg;
	}

	public WebElement getScannerTypeMandatoryMsg() {
		return scannerTypeMandatoryMsg;
	}

	public WebElement getChequeList1stLineOnusReferral() {
		return chequeList1stLineOnusReferral;
	}

	public WebElement getOnusParallelReferralProcessing() {
		return onusParallelReferralProcessing;
	}

	public WebElement getOnusV1DateSelection() {
		return onusV1DateSelection;
	}

	public WebElement getBtnsigcapVerification() {
		return btnsigcapVerification;
	}

	public WebElement getBtngetsigcapVerification() {
		return btngetsigcapVerification;
	}
	
	public WebElement getBtnsigcapClose() {
		return btnsigcapClose;
	}

	public WebElement getBtnOverride() {
		return btnOverride;
	}

	public WebElement getTxtAmountFieldItemFinder() {
		return txtAmountFieldItemFinder;
	}

	public WebElement getOnus() {
		return onus;
	}

	public WebElement getOnusProcess() {
		return onusProcess;
	}

	public WebElement getOnusTechnicalVerificationI() {
		return onusTechnicalVerificationI;
	}

	public WebElement getOnusTechnicalVerificationII() {
		return onusTechnicalVerificationII;
	}

	public WebElement getSearchItemFinderdd() {
		return searchItemFinderdd;
	}

	public WebElement getSearchItemFinderOption() {
		return searchItemFinderOption;
	}

	public WebElement getOutwardAndOnus() {
		return outwardAndOnus;
	}

	public WebElement getTxtOnusV1BussinessDate() {
		return txtOnusV1BussinessDate;
	}

	public WebElement getTxtOnusV2BussinessDate() {
		return txtOnusV2BussinessDate;
	}

	public WebElement getTxtOnusBatchNumber() {
		return txtOnusBatchNumber;
	}

	public WebElement getTxtOnusV2ChequeNum() {
		return txtOnusV2ChequeNum;
	}

	public WebElement getProcessTypedd() {
		return processTypedd;
	}

	public WebElement getOnusprocessTypedd() {
		return OnusprocessTypedd;
	}

	public WebElement getBtnSearch() {
		return btnSearch;
	}

	public WebElement getChequelist1stline() {
		return chequelist1stline;
	}

	public WebElement getChequeStatus() {
		return chequeStatus;
	}

	public WebElement getBtnReturn() {
		return btnReturn;
	}

	public WebElement getBtnAccept() {
		return btnAccept;
	}

	public WebElement getReturnReason() {
		return returnReason;
	}

	public WebElement getOptionMultilatedItem() {
		return optionMultilatedItem;
	}

	public WebElement getTapCloseIcon() {
		return tapCloseIcon;
	}

	public WebElement getTxtAmount() {
		return txtAmount;
	}

	public WebElement getChequeBatchIDV1() {
		return chequeBatchIDV1;
	}

	public WebElement getChequeNumV1() {
		return chequeNumV1;
	}
	
	public WebElement getMenuIcon() {
		return menuIcon;
	}
	
	
	public WebElement getPhysicalChequeValidation() {
		return physicalChequeValidation;
	}

	public WebElement getBtnDeletePhysicalchequeVali() {
		return btnDeletePhysicalchequeVali;
	}

	public WebElement getBtnVerifyPhysicalchequeVali() {
		return btnVerifyPhysicalchequeVali;
	}
	public WebElement getBtnOK() {
		return btnOK;
	}

	public WebElement getBtnYes() {
		return btnYes;
	}
	
	public WebElement getTodayV2BussinessDate() {
		return todayV2BussinessDate;
	}
	
	/**
	 *@author ParasuramK Onus Process Maker & Checker Return & Accept Flow Methods
	 */

	public void onusMaker(String batchNum) throws AWTException, InterruptedException {
		elementClick(getOnus());
		elementClick(getOnusProcess());
		elementClick(getOnusTechnicalVerificationI());
		elementClick(getTxtOnusV1BussinessDate());
		elementClick(getOnusV1DateSelection());
		elementInsertValue(getTxtOnusBatchNumber(), batchNum);
		elementClick(getBtnSearch());
		Thread.sleep(2000);
		elementClick(getChequelist1stline());
		Thread.sleep(3000);

	}
	public String onusChequeNum()  {
		String chequeNum = elementGetAttribute(getChequeNumV1());
		return chequeNum;
	}
	
	public void onusReturnMaker(String amount) throws AWTException, InterruptedException {
		elementClick(getTxtAmount());
		clearTextBox(getTxtAmount());
		elementInsertValue(getTxtAmount(),amount);
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnReturn());
		Thread.sleep(2000);	
		explicitWait(10,getBtnOK());
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getReturnReason());		
		Thread.sleep(2000);
		elementClick(getOptionMultilatedItem());
		elementClick(getBtnReturn());
		explicitWait(10,getBtnOK());
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}	
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getTapCloseIcon().isDisplayed()) {
		elementClick(getTapCloseIcon());
		}else if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		else  {
			elementClick(getTapCloseIcon());
		}

	}
	public void search_ItemFinder(String chequeNum,String chequeAmount) throws InterruptedException {
		Thread.sleep(1000);
		elementClick(getSearchItemFinderdd());
		elementClick(getSearchItemFinderOption());
		elementClick(getOutwardAndOnus());
		elementInsertValue(getTxtOnusV2ChequeNum(), chequeNum);
		elementInsertValue(getTxtAmountFieldItemFinder(), chequeAmount);
		elementClick(getProcessTypedd());
		elementClick(getOnusprocessTypedd());
		elementClick(getBtnSearch());
	}
	public String onuschequeStatus() {
		String chequeStatus = elementGetText(getChequeStatus());
		elementClick(getTapCloseIcon());
		return chequeStatus;		
		

	}
	public void onusChecker(String chequeNum) throws AWTException, InterruptedException {
		elementClick(getOnus());
		elementClick(getOnusProcess());
		elementClick(getOnusTechnicalVerificationII());
		Thread.sleep(2000);
		elementClick(getTxtOnusV2BussinessDate());
		elementClick(getOnusV1DateSelection());
		elementInsertValue(getTxtOnusV2ChequeNum(), chequeNum);
		elementClick(getBtnSearch());
		Thread.sleep(2000);
		elementClick(getChequelist1stline());
		Thread.sleep(1500);
		
	}
	public void onusReturnByChecker(String amount) throws InterruptedException, AWTException {
		elementInsertValue(getTxtAmount(),amount);
		Thread.sleep(1000);
		elementClick(getBtnReturn());
		elementClick(getBtnReturn());
		Thread.sleep(2000);	
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getReturnReason());		
		Thread.sleep(2000);
		elementClick(getOptionMultilatedItem());
		elementClick(getBtnReturn());
		explicitWait(10,getBtnOK());
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}	
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getTapCloseIcon().isDisplayed()) {
		elementClick(getTapCloseIcon());
		}else if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		else  {
			elementClick(getTapCloseIcon());
		}

	}
	
	public void physicalChequeValidation(String chequeNum) throws InterruptedException, AWTException {
		elementClick(getOnusProcess());
		Thread.sleep(1500);
		elementClick(getOnusProcess());
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getPhysicalChequeValidation());
		elementClick(getPhysicalChequeValidation());
		elementClick(getTxtOnusV2BussinessDate());
		elementClick(getOnusV1DateSelection());
		Robot robot = new Robot();
		elementInsertValue(getTxtOnusV2ChequeNum(), chequeNum);
		elementClick(getBtnSearch());
		Thread.sleep(2000);
		elementClick(getChequelist1stline());
		Thread.sleep(1500);
		elementClick(getBtnVerifyPhysicalchequeVali());
		explicitWait(10,getBtnYes());
		if(getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		}
		explicitWait(10,getBtnOK());
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);

		if(getTapCloseIcon().isDisplayed()) {
		elementClick(getTapCloseIcon());
		}
		else {
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			elementClick(getTapCloseIcon());
		}
	}
	public void onusAcceptByMaker(String amount) throws AWTException, InterruptedException {
		elementClick(getTxtAmount());
		clearTextBox(getTxtAmount());
		elementInsertValue(getTxtAmount(),amount);
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnAccept());
		Thread.sleep(3000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);//no batch found
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);//no batch found
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getTapCloseIcon().isDisplayed()) {
		elementClick(getTapCloseIcon());
		}else if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		else  {
			elementClick(getTapCloseIcon());
		}
	}
	public void onusAcceptByChecker(String amount) throws InterruptedException, AWTException {
		elementInsertValue(getTxtAmount(),amount);
		Thread.sleep(1000);
		elementClick(getBtnsigcapVerification());
		Thread.sleep(1000);
		elementClick(getBtnsigcapClose());
		explicitWait(10,getBtngetsigcapVerification());
		elementClick(getBtngetsigcapVerification());
		Thread.sleep(1000);	
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnOverride());
		Thread.sleep(1000);
		if(getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		}
		else {
			elementClick(getBtnOK());
		}
		elementClick(getBtnAccept());
		Thread.sleep(10000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		} 
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if(getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);

		elementClick(getTapCloseIcon());
	}
	public void onusParallelReferralProcessing(String chequeNum) throws InterruptedException {
		elementClick(getOnus());
		elementClick(getOnusProcess());
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", getOnusParallelReferralProcessing());
		elementClick(getOnusParallelReferralProcessing());
		elementClick(getTxtOnusV2BussinessDate());
		elementClick(getOnusV1DateSelection());
		elementInsertValue(getTxtOnusV2ChequeNum(), chequeNum);
		elementClick(getBtnSearch());
		Thread.sleep(2000);
		elementClick(getChequeList1stLineOnusReferral());
		elementClick(getBtnAccept());
		Thread.sleep(1000);
		elementClick(getBtnYes());//confirmation to access
		Thread.sleep(1000);
		elementClick(getBtnOK());//accept ok
		Thread.sleep(1000);
		elementClick(getBtnOK());//No instrument found
		Thread.sleep(1000);
		elementClick(getTapCloseIcon());
		
	}
	
	/***@author ParasuramK below followed methods for Field verification */
	
	/**
	 * @author ParasuramK Onus Branch Cheque Capture Field Verification
	 */
	
	public boolean onusBranchChequeCaptureIsClickable() {
		elementClick(getOnus());
		elementClick(getOnusProcess());
		boolean enabled = getOnusBranchChequeCapture().isEnabled();
		return enabled;
	}
	public boolean presentationTypeisMandatory() {
		elementClick(getOnusBranchChequeCapture());
		elementClick(getBtnInitialize());
		boolean displayed = getPresentationTypeMandatoryMsg().isDisplayed();
		return displayed;
	}
	public void acceptOKMsg() {
		explicitWait(5, getBtnOK());
		elementClick(getBtnOK());
	}
	public boolean scannerTypeisMandatory() {
		acceptOKMsg();
		elementClick(getDdIconPresentationType());
		explicitWait(5, getDdNormalPresentationType());
		elementClick(getDdNormalPresentationType());
		elementClick(getBtnInitialize());
		boolean displayed = getScannerTypeMandatoryMsg().isDisplayed();
		return displayed;
	}
	public boolean initializebuttonisClickable() {
		acceptOKMsg();
		elementClick(getDdIconScannerType());
		elementClick(getDdSmartsourceScannerType());
		boolean enabled = getBtnInitialize().isEnabled();
		return enabled;
	}
	public boolean startbuttonisClickable() {
		elementClick(getBtnInitialize());
		explicitWait(5, getBtnProceed());
		elementClick(getBtnProceed());
		explicitWait(5, getBtnStart());
		boolean enabled = getBtnStart().isEnabled();
		return enabled;
	}
	public boolean stopbuttonisClickable() {
		elementClick(getBtnStart());
		explicitWait(5, getBtnStop());
		boolean enabled = getBtnStop().isEnabled();
		return enabled;
	}
	public boolean finishbuttonisClickable() {
		elementClick(getBtnStop());
		explicitWait(5, getBtnYes());
		elementClick(getBtnYes());
		explicitWait(5, getBtnFinish());
		boolean enabled = getBtnFinish().isEnabled();
		return enabled;
	}
	
	/**
	 * @author ParasuramK Scan Verification Field Verification
	 */
	public boolean scanVerificationIsClickable() {
		elementClick(getOnus());
		elementClick(getOnusProcess());
		boolean enabled = getScanVerificationMenu().isEnabled();
		return enabled;
	}
	public boolean scanVerificationBusinessDateisMandatory() {
		elementClick(getScanVerificationMenu());
		elementClick(getBtnSearch());
		boolean displayed = getBusinessDateisMandatoryMsg().isDisplayed();
		return displayed;
	}
	public boolean scanVerificationSearchButtonisClickable() {
		acceptOKMsg();
		boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}
	/**
	 * @author ParasuramK Onus OPC Reject Repair Maker Field Verification
	 */
		
	public boolean onusOPCRejectRepairMakerIsClickable() {
		elementClick(getOnus());
		elementClick(getOnusProcess());
		boolean enabled = getOnusOPCRejectRepairMakerMenu().isEnabled();
		return enabled;
	}
	public boolean onusOPCRejectRepairMakerBusinessDateisMandatory() {
		elementClick(getOnusOPCRejectRepairMakerMenu());
		elementClick(getBtnSearch());
		boolean displayed = getEnterBusinessDateisMandatoryMsg().isDisplayed();
		return displayed;
	}
	public boolean onusOPCRejectRepairMakerSearchButtonisClickable() {
		acceptOKMsg();
		boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}
	/**
	 * @author ParasuramK Physical Cheque Validation Field Verification
	 */
	public boolean physicalChequevalidationisClickable() {
		elementClick(getOnus());
		elementClick(getOnusProcess());
		boolean enabled = getPhysicalChequeValidation().isEnabled();
		return enabled;
	}
    public boolean physicalChequeValidationBusinessDateMandatoryField() {
    	elementClick(getPhysicalChequeValidation());
    	elementClick(getBtnSearch());
    	boolean enabled = getBusinessDateisMandatoryMsg().isEnabled();
    	return enabled;
	}
    public boolean physicalChequeValidationSearchButtonIsClickable() {
    	acceptOKMsg();
    	boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}
    public boolean physicalChequeValidationBatchDetailisClickable() throws InterruptedException {
    	Thread.sleep(1000);
    	elementClick(getTxtOnusV2BussinessDate());
    	explicitWait(5, getOnusV1DateSelection());
    	elementClick(getOnusV1DateSelection());
    	elementClick(getBtnSearch());
		explicitWait(5, getChequeList1stLineOnusReferral());
		boolean enabled = getChequeList1stLineOnusReferral().isEnabled();
		return enabled;
	}
    public boolean physicalChequeValidationBatchDetailBackbuttonisClickable() {
		boolean enabled = getBtnBack().isEnabled();
		return enabled;
	}
    public boolean physicalChequeValidationBatchDetailVerifybuttonisClickable() {
    	boolean enabled = getBtnVerifyOnBatchDetailsPhysicalCV().isEnabled();
    	return enabled;
	}
    public boolean physicalChequeValidationBatchDetailDeletebuttonisClickable() {
    	boolean enabled = getBtnDeleteOnBatchDetailsPhysicalCV().isEnabled();
    	return enabled;    	
	}
    /**
     * @author ParasuramK Checkerwise Verified SatusField Verification
     */
    public boolean checkerWiseVerifiedStatusisClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
    	boolean enabled = getCheckerWiseVerifiedStatusMenu().isEnabled();
    	return enabled;
	}
    
    public boolean checkerWiseVerifiedStatusRefreshbuttonisClickable(){
    	elementClick(getCheckerWiseVerifiedStatusMenu());
    	if(getBtnOK().isEnabled()) {
			elementClick(getBtnOK());
		}
		boolean enabled = getBtnRefresh().isEnabled();
		return enabled;
	}
    
    /**
     * @author ParasuramK Makerwise Processing status Field Verification
     */
    
    public boolean makerwiseProcessingStatusisClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
    	boolean enabled = getMakerWiseProcessingStatusMenu().isEnabled();
    	return enabled;
	}
    
    public boolean makerwiseProcessingStatusRefreshbuttonisClickable(){
    	elementClick(getMakerWiseProcessingStatusMenu());
    	if(getBtnOK().isEnabled()) {
			elementClick(getBtnOK());
		}
		boolean enabled = getBtnRefresh().isEnabled();
		return enabled;
	}
    /**
     * @author ParasuramK Onus ChannelWise Processing Status Dashboard Field Verification
     */
    public boolean onusChannelWiseProcessingStatusDashboardisClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
		boolean enabled = getOnusChannelWiseProcessingStatusDashboardMenu().isEnabled();
    	return enabled;
	}
    public boolean onusChannelWiseProcessingStatusDashboardRefreshbuttonisClickable() {
    	elementClick(getOnusChannelWiseProcessingStatusDashboardMenu());
		boolean enabled = getBtnRefresh().isEnabled();
		return enabled;
	}
	/**
	 * @author ParasuramK Onus Finacle Dashboard Field Verification
	 */
    public boolean onusFinacleDashboardisClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
    	boolean enabled = getOnusFinacleDashboardMenu().isEnabled();
    	return enabled;
	}
    public boolean onusFinacleDashboardRefreshbuttonisClickable() {
		elementClick(getOnusFinacleDashboardMenu());
		boolean enabled = getBtnRefresh().isEnabled();
    	return enabled;
	}
    /**
     * @author ParasuramK Onus Refferal Dashboard Field Verification
     */
    public boolean onusRefferalDashboardisClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
    	boolean enabled = getOnusRefferalDashboardMenu().isEnabled();
    	return enabled;
	}
    public boolean onusRefferalDashboardRefreshbuttonisClickable() throws InterruptedException {
    	elementClick(getOnusRefferalDashboardMenu());
    	try
    	{
    		if(getBtnOK().isEnabled()) {
    			elementClick(getBtnOK());
    	}
			
		}catch(NoSuchElementException e) {
			
		}
    	boolean enabled = getBtnRefresh().isEnabled();
		return enabled;
	}
    /**
     * @author ParasuramK Onus Branch Referral Crad Field Verification
     */
    public boolean onusBranchReferralCradIsClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
    	boolean enabled = getOnusBranchReferralCradMenu().isEnabled();
    	return enabled;
	}
    public boolean onusBranchReferralCradTheBusinessDateMandatoryField() {
    	elementClick(getOnusBranchReferralCradMenu());
    	elementClick(getBtnSearch());
    	boolean displayed = getBusinessDateisMandatoryMsg().isDisplayed();
    	return displayed;
    }
    
    public boolean onusBranchReferralCradSearchbuttonIsClickable() {
    	boolean enabled = getBtnSearch().isEnabled();
    	return enabled;
    }
    public boolean onusBranchReferralCradBatchdetailsareClickable() throws InterruptedException {
    	Thread.sleep(1000);
    	elementClick(getTxtOnusV2BussinessDate());
    	explicitWait(5, getOnusV1DateSelection());
    	elementClick(getOnusV1DateSelection());
    	elementClick(getBtnSearch());
    	boolean enabled = getChequeList1stLineOnusReferral().isEnabled();
    	return enabled;
    }
    public boolean onusBranchReferralCradBackbuttonisClickable() {
    	boolean enabled = getBtnBack().isEnabled();
		return enabled;
    }
    public boolean onusBranchReferralCradAcceptbuttonisClickable() {
    	boolean enabled = getBtnAccept().isEnabled();
		return enabled;
    }
    public boolean onusBranchReferralCradReturnbuttonisClickable() {
    	boolean enabled = getBtnReturn().isEnabled();
		return enabled;
    }
    
    /**
     * @author ParasuramK Onus Dashboard Field Verification
     */
    public boolean onusDashboardisClikable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
    	boolean enabled = getOnusDashboardMenu().isEnabled();
    	return enabled;
	}
    public void onusDashboard() {
		elementClick(getOnusDashboardMenu());

	}
    
    /**
     * @author ParasuramK Onus OPC Arabic Reject Repair Maker Field Verification
     */
    public boolean onusOPCArabicRejectRepairMakerIsClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
		boolean enabled = getOnusOPCArabicRejectRepairMakerMenu().isEnabled();
		return enabled;
	}
    public boolean onusOPCArabicRejectRepairMakerBusinessDateisMandatory() {
		elementClick(getOnusOPCArabicRejectRepairMakerMenu());
		elementClick(getBtnSearch());
		boolean displayed = getEnterBusinessDateisMandatoryMsg().isDisplayed();
		return displayed;
	}
    public boolean onusOPCArabicRejectRepairMakerSearchbuttonIsClickable() {
		boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}
    public boolean onusOPCArabicRejectRepairMakerBatchdetailsareClickable() throws InterruptedException {
    	Thread.sleep(1000);
    	elementClick(getTxtOnusV2BussinessDate());
    	explicitWait(5, getOnusV1DateSelection());
    	elementClick(getOnusV1DateSelection());
    	elementClick(getBtnSearch());
    	boolean enabled = getChequeList1stLineOnusReferral().isEnabled();
    	return enabled;
    }
    public boolean onusOPCArabicRejectRepairMakerBackbuttonisClickable() {
    	boolean enabled = getBtnBack().isEnabled();
		return enabled;
    }
    public boolean onusOPCArabicRejectRepairMakerReleaseLockbuttonisClickable() {
    	boolean enabled = getBtnReleaseLock().isEnabled();
		return enabled;
    }
    public boolean onusOPCArabicRejectRepairMakerDeletebuttonisClickable() {
    	boolean enabled = getBtnDeleteOnBatchDetailsPhysicalCV().isEnabled();
		return enabled;
    }
    
    /**
     * @author ParasuramK Onus Parallel Referral Processing Field Verification
     */
    public boolean onusParallelReferralProcessingIsClickable() {
    	elementClick(getOnus());
		elementClick(getOnusProcess());
		boolean enabled = getOnusParallelReferralProcessingMenu().isEnabled();
		return enabled;
	}
    public boolean onusParallelReferralProcessingBusinessDateisMandatory() {
		elementClick(getOnusParallelReferralProcessingMenu());
		elementClick(getBtnSearch());
		boolean displayed = getBusinessDateisMandatoryMsg().isDisplayed();
		return displayed;
	}
    public boolean onusParallelReferralProcessingSearchbuttonIsClickable() {
		boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}
    public boolean onusParallelReferralProcessingBatchdetailsareClickable() throws InterruptedException {
    	Thread.sleep(1000);
    	elementClick(getTxtOnusV2BussinessDate());
    	explicitWait(5, getOnusV1DateSelection());
    	elementClick(getOnusV1DateSelection());
    	elementClick(getBtnSearch());
    	boolean enabled = getChequeList1stLineOnusReferral().isEnabled();
    	return enabled;
    }
    public boolean onusParallelReferralProcessingBackbuttonisClickable() {
    	boolean enabled = getBtnBack().isEnabled();
		return enabled;
    }
    public boolean onusParallelReferralProcessingAcceptbuttonisClickable() {
    	boolean enabled = getBtnAccept().isEnabled();
		return enabled;
    }
    public boolean onusParallelReferralProcessingReturnbuttonisClickable() {
    	boolean enabled = getBtnReturn().isEnabled();
		return enabled;
    }
    /**
     * @author ParasuramK Onus tech verification1 Arabic Field Verification
     */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
