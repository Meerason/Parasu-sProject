package com.pages;

import java.awt.AWTException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.base.BaseClass;

public class InwardTechnicalVerifier extends BaseClass {
	public InwardTechnicalVerifier() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[text()='Inward  Processing']")
	private WebElement inwardProcessing;

	@FindBy(xpath = "//span[text()='Inward  Clearing']")
	private WebElement inwardClearing;

	@FindBy(xpath = "(//i[@class='z-borderlayout-icon z-icon-chevron-right'])[1]")
	private WebElement menuIcon;

	@FindBy(xpath = "//span[text()='Inward Technical Verifier 1']")
	private WebElement InwardTechnicalVerifier1;

	@FindBy(xpath = "//span[text()='Inward Technical Verifier 2']")
	private WebElement InwardTechnicalVerifier2;

	@FindBy(xpath = "//span[text()='Inward  Processing']/parent::a/following-sibling::ul/li/ul//span[text()='Search/Item Finder']")
	private WebElement inwardsearchitemFinder;

	@FindBy(xpath = "(//div[@class='z-listcell-content'])[13]")
	private WebElement chequeStatus;

	@FindBy(xpath = "//span[text()='Business Date *']/parent::td/following-sibling::td/span/a")
	private WebElement txtBusinessDate;

	@FindBy(xpath = "//span[text()='cheque Number']/parent::td/following-sibling::td/input")
	private WebElement txtchequeNumber;

	@FindBy(xpath = "//button[text()='Search']")
	private WebElement btnSearch;

	@FindBy(xpath = "//div[@class='z-listbox-body']/table/tbody/tr[1]/td[1]/div")
	private WebElement chequelist1stline;

	@FindBy(xpath = "//div[@class='z-listbox-body']/table/tbody/tr[1]/td[2]")
	private WebElement chequelist1stlineVerifier2;

	@FindBy(xpath = "//div[@class='z-listbox-body']/table/tbody/tr[1]/td[1]/div/span")
	private WebElement referralchequelist1stline;

	@FindBy(xpath = "//span[text()='Batch ID :']/parent::div//parent::td/following-sibling::td/div/span")
	private WebElement chequeverifyBatchID;

	@FindBy(xpath = "(//input[@class='z-textbox z-textbox-readonly'])[1]")
	private WebElement chequeNum;

	@FindBy(xpath = "(//input[@class='z-textbox z-textbox-readonly'])[4]")
	private WebElement chequeAmount;

	@FindBy(xpath = "//button[text()='Sigcap Verification']")
	private WebElement btnsigcapVerification;

	@FindBy(xpath = "//button[text()='Get Sigcap Result']")
	private WebElement btngetsigcapVerification;

	@FindBy(xpath = "//button[text()='Override']")
	private WebElement btnOverride;

	@FindBy(xpath = "//button[text()='Return']")
	private WebElement btnReturn;

	@FindBy(xpath = "//button[text()='Submit']")
	private WebElement btnSubmit;

	@FindBy(xpath = "//button[text()='Accept']")
	private WebElement btnAccept;

	@FindBy(xpath = "//span[text()='Cheque Number']/parent::div/parent::td/following-sibling::td/div/input")
	private WebElement itemfinderChequeNum;

	@FindBy(xpath = "//span[text()='Amount']/parent::div/parent::td/following-sibling::td/div/input")
	private WebElement itemfinderChequeAmount;

	@FindBy(xpath = "//span[text()='Batch Number']/parent::td/following-sibling::td/input")
	private WebElement txtBatchNum;
	
	@FindBy(xpath = "//span[text()='Batch Number']/parent::div/parent::td/following-sibling::td/div/input")
	private WebElement txtBatchNumVerifier2;

	@FindBy(xpath = "//button[text()='Skip']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement returnReason;

	@FindBy(xpath = "/html/body/div[3]/ul/li[3]/span[2]")
	private WebElement optionMultilatedItem;

	@FindBy(xpath = "/html/body/div[4]/ul/li[3]/span[2]")
	private WebElement optionMultilatedItemVerifier2;

	@FindBy(xpath = "(//i[@class='z-icon-times z-tab-icon'])[1]")
	private WebElement tapCloseIcon;

	@FindBy(xpath = "//span[text()='Business Date *']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement txtVerifier2BussinessDate;

	@FindBy(xpath = "//span[text()='Business Date*']/parent::div/parent::td/following-sibling::td/div/span/a")
	private WebElement txtBussinessDateinwardReferral;

	@FindBy(xpath = "//span[text()='Cheque Number']/parent::div/parent::td/following-sibling::td/div/input")
	private WebElement txtVerifier2ChequeNum;

	@FindBy(xpath = "(//input[@class='z-textbox z-textbox-readonly'])[3]")
	private WebElement verifier2AcctNum;

	@FindBy(xpath = "(//input[@class='z-textbox'])[7]")
	private WebElement txtVerifier2AcctNum;

	@FindBy(xpath = "//div[@class='z-window-icon z-window-close']")
	private WebElement btnsigcapClose;

	@FindBy(xpath = "//button[text()='OK']")
	private WebElement btnOK;

	@FindBy(xpath = "//button[text()='Yes']")
	private WebElement btnYes;

	@FindBy(xpath = "//span[text()='Inward Parallel Referral Processing']")
	private WebElement inwardParallelReferralProcessing;

	@FindBy(xpath = "//div[@class='z-combobox-popup  z-combobox-open z-combobox-shadow']/ul/li[1]")
	private WebElement inwardV1DateSelection;

	@FindBy(xpath = "//span[text()='Please select business date !']")
	private WebElement plsSelectBDate;

	@FindBy(xpath = "//span[text()='Inward Dashboard']")
	private WebElement inwardDashboardmenu;

	@FindBy(xpath = "//span[text()='Inward Parsing ']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconInwardParsing;
	@FindBy(xpath = "//span[text()='QR Code Validation']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconQRCodeValidation;
	@FindBy(xpath = "//span[text()='OCR Service']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconOCRService;
	@FindBy(xpath = "//span[text()='DSA Validation']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconDSAValidation;
	@FindBy(xpath = "//span[text()='ASV Status']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconASVStatus;
	@FindBy(xpath = "//span[text()='ICR Service']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconICRService;
	@FindBy(xpath = "//span[text()='Technical Verification 1 (OPC)']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconTechnicalVerification1;
	@FindBy(xpath = "//span[text()='OPC Technical Verification 2 (OPC)']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconTechnicalVerification2;
	@FindBy(xpath = "//span[text()='Referral/ Branch Referral/ Crad']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconReferralBranchReferralCrad;
	@FindBy(xpath = "//span[text()='Posting to Finacle']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconPostingtoFinacle;
	@FindBy(xpath = "//span[text()='Active CR']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconActiveCR;
	@FindBy(xpath = "//span[text()='RCE File Creation']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconRCEFileCreation;
	@FindBy(xpath = "//span[text()='RAK File Parsing']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconRAKFileParsing;
	@FindBy(xpath = "//span[text()='NACK Reject Reprocessing']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconNACKRejectReprocessing;
	@FindBy(xpath = "//span[text()='Finacle']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconFinacle;
	@FindBy(xpath = "//span[text()='Awaiting']/ancestor::td/preceding-sibling::td/div/button")
	private WebElement plusIconAwaiting;
	
	
	@FindBy(xpath = "//span[text()='Inward Bank Wise Summary Dashboard']")
	private WebElement inwardBankWiseSummaryDashboardmenu;
	@FindBy(xpath = "//button[text()='Refresh']")
	private WebElement btnRefresh;
	
	@FindBy(xpath = "//span[text()='Inward Central Bank Status Dashboard']")
	private WebElement inwardCentralBankStatusDashboardmenu;
	
	@FindBy(xpath = "//span[text()='Inward Finacle Dashboard']")
	private WebElement inwardFinacleDashboardmenu;
	
	@FindBy(xpath = "//span[text()='Inward Referral Dasboard']")
	private WebElement inwardReferralDashboardmenu;
	
	@FindBy(xpath = "//span[text()='Inward Userwise Dashboard']")
	private WebElement inwardUserwiseDashboardmenu;
	
	@FindBy(xpath = "//span[text()='Consolidated Posting Inward']")
	private WebElement consolidatedPostingInwardmenu;
	
	@FindBy(xpath = "//span[text()='Inward Technical Verifier 1 Arabic']")
	private WebElement inwardTechnicalVerifier1Arabicmenu;
	
	@FindBy(xpath = "//span[text()='Reject Repair Maker']")
	private WebElement rejectRepairMakerMenu;
	
	@FindBy(xpath = "//span[text()='Reject Repair Maker Arabic']")
	private WebElement rejectRepairMakerArabicMenu;
	
	@FindBy(xpath = "//span[text()='Inward Branch Referral Crad']")
	private WebElement inwardBranchReferralCradMenu;
	
	@FindBy(xpath = "//button[text()='Return Exception']")
	private WebElement btnReturnException;
	
	@FindBy(xpath = "//button[text()='Skip']")
	private WebElement btnSkip;
	
	@FindBy(xpath = "//button[text()='Send Back']")
	private WebElement btnSendBack;
	
	@FindBy(xpath = "//span[text()='Inward Technical Verifier 2 Arabic']")
	private WebElement inwardTechnicalVerifier2Arabicmenu;
	
	
				
	public WebElement getInwardTechnicalVerifier2Arabicmenu() {
		return inwardTechnicalVerifier2Arabicmenu;
	}

	public WebElement getTxtBatchNumVerifier2() {
		return txtBatchNumVerifier2;
	}

	public WebElement getBtnSendBack() {
		return btnSendBack;
	}

	public WebElement getBtnReturnException() {
		return btnReturnException;
	}

	public WebElement getBtnSkip() {
		return btnSkip;
	}

	public WebElement getInwardBranchReferralCradMenu() {
		return inwardBranchReferralCradMenu;
	}

	public WebElement getRejectRepairMakerArabicMenu() {
		return rejectRepairMakerArabicMenu;
	}

	public WebElement getRejectRepairMakerMenu() {
		return rejectRepairMakerMenu;
	}

	public WebElement getInwardTechnicalVerifier1Arabicmenu() {
		return inwardTechnicalVerifier1Arabicmenu;
	}

	public WebElement getConsolidatedPostingInwardmenu() {
		return consolidatedPostingInwardmenu;
	}

	public WebElement getInwardUserwiseDashboardmenu() {
		return inwardUserwiseDashboardmenu;
	}

	public WebElement getInwardReferralDashboardmenu() {
		return inwardReferralDashboardmenu;
	}

	public WebElement getInwardFinacleDashboardmenu() {
		return inwardFinacleDashboardmenu;
	}

	public WebElement getInwardCentralBankStatusDashboardmenu() {
		return inwardCentralBankStatusDashboardmenu;
	}

	public WebElement getInwardBankWiseSummaryDashboardmenu() {
		return inwardBankWiseSummaryDashboardmenu;
	}

	public WebElement getBtnRefresh() {
		return btnRefresh;
	}

	public WebElement getInwardDashboardmenu() {
		return inwardDashboardmenu;
	}

	public WebElement getPlusIconInwardParsing() {
		return plusIconInwardParsing;
	}

	public WebElement getPlusIconQRCodeValidation() {
		return plusIconQRCodeValidation;
	}

	public WebElement getPlusIconOCRService() {
		return plusIconOCRService;
	}

	public WebElement getPlusIconDSAValidation() {
		return plusIconDSAValidation;
	}

	public WebElement getPlusIconASVStatus() {
		return plusIconASVStatus;
	}

	public WebElement getPlusIconICRService() {
		return plusIconICRService;
	}

	public WebElement getPlusIconTechnicalVerification1() {
		return plusIconTechnicalVerification1;
	}

	public WebElement getPlusIconTechnicalVerification2() {
		return plusIconTechnicalVerification2;
	}

	public WebElement getPlusIconReferralBranchReferralCrad() {
		return plusIconReferralBranchReferralCrad;
	}

	public WebElement getPlusIconPostingtoFinacle() {
		return plusIconPostingtoFinacle;
	}

	public WebElement getPlusIconActiveCR() {
		return plusIconActiveCR;
	}

	public WebElement getPlusIconRCEFileCreation() {
		return plusIconRCEFileCreation;
	}

	public WebElement getPlusIconRAKFileParsing() {
		return plusIconRAKFileParsing;
	}

	public WebElement getPlusIconNACKRejectReprocessing() {
		return plusIconNACKRejectReprocessing;
	}

	public WebElement getPlusIconFinacle() {
		return plusIconFinacle;
	}

	public WebElement getPlusIconAwaiting() {
		return plusIconAwaiting;
	}

	public WebElement getInwardV1DateSelection() {
		return inwardV1DateSelection;
	}

	public WebElement getBtnOK() {
		return btnOK;
	}

	public WebElement getPlsSelectBDate() {
		return plsSelectBDate;
	}

	public WebElement getBtnYes() {
		return btnYes;
	}

	public WebElement getInwardProcessing() {
		return inwardProcessing;
	}

	public WebElement getInwardClearing() {
		return inwardClearing;
	}

	public WebElement getMenuIcon() {
		return menuIcon;
	}

	public WebElement getInwardTechnicalVerifier1() {
		return InwardTechnicalVerifier1;
	}

	public WebElement getInwardTechnicalVerifier2() {
		return InwardTechnicalVerifier2;
	}

	public WebElement getInwardsearchitemFinder() {
		return inwardsearchitemFinder;
	}

	public WebElement getTxtBusinessDate() {
		return txtBusinessDate;
	}

	public WebElement getTxtchequeNumber() {
		return txtchequeNumber;
	}

	public WebElement getBtnSearch() {
		return btnSearch;
	}

	public WebElement getChequelist1stline() {
		return chequelist1stline;
	}

	public WebElement getChequeverifyBatchID() {
		return chequeverifyBatchID;
	}

	public WebElement getChequeNum() {
		return chequeNum;
	}

	public WebElement getChequeAmount() {
		return chequeAmount;
	}

	public WebElement getBtnsigcapVerification() {
		return btnsigcapVerification;
	}

	public WebElement getBtngetsigcapVerification() {
		return btngetsigcapVerification;
	}

	public WebElement getBtnOverride() {
		return btnOverride;
	}

	public WebElement getBtnReturn() {
		return btnReturn;
	}

	public WebElement getBtnAccept() {
		return btnAccept;
	}

	public WebElement getItemfinderChequeNum() {
		return itemfinderChequeNum;
	}

	public WebElement getItemfinderChequeAmount() {
		return itemfinderChequeAmount;
	}

	public WebElement getTxtBatchNum() {
		return txtBatchNum;
	}

	public WebElement getReturnReason() {
		return returnReason;
	}

	public WebElement getOptionMultilatedItem() {
		return optionMultilatedItem;
	}

	public WebElement getChequeStatus() {
		return chequeStatus;
	}

	public WebElement getTapCloseIcon() {
		return tapCloseIcon;
	}

	public WebElement getOptionMultilatedItemVerifier2() {
		return optionMultilatedItemVerifier2;
	}

	public WebElement getTxtVerifier2BussinessDate() {
		return txtVerifier2BussinessDate;
	}

	public WebElement getTxtVerifier2ChequeNum() {
		return txtVerifier2ChequeNum;
	}

	public WebElement getVerifier2AcctNum() {
		return verifier2AcctNum;
	}

	public WebElement getTxtVerifier2AcctNum() {
		return txtVerifier2AcctNum;
	}

	public WebElement getBtnsigcapClose() {
		return btnsigcapClose;
	}

	public WebElement getChequelist1stlineVerifier2() {
		return chequelist1stlineVerifier2;
	}

	public WebElement getReferralchequelist1stline() {
		return referralchequelist1stline;
	}

	public WebElement getBtnSubmit() {
		return btnSubmit;
	}

	public WebElement getTxtBussinessDateinwardReferral() {
		return txtBussinessDateinwardReferral;
	}

	public WebElement getInwardParallelReferralProcessing() {
		return inwardParallelReferralProcessing;
	}

	/**
	 * @author parasuramk -Inward Regression Flow Methods
	 */
	public void inward(String batchNum) throws Exception {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		elementClick(getInwardTechnicalVerifier1());
		elementClick(getTxtBusinessDate());
		elementClick(getInwardV1DateSelection());
		Thread.sleep(1000);
		elementInsertValue(getTxtBatchNum(), batchNum);
		elementClick(getBtnSearch());
		Thread.sleep(2000);
		elementClick(getChequelist1stline());
		Thread.sleep(2000);

	}

	public String inwardChequeNum() {
		String chequeNum = elementGetAttribute(getChequeNum());
		return chequeNum;
	}

	public String inwardChequeAmount() {
		String chequeAmount = elementGetAttribute(getChequeAmount());
		return chequeAmount;
	}

	public void inwardReturn() throws Exception {
		elementClick(getBtnsigcapVerification());
		Thread.sleep(1000);
		elementClick(getBtnsigcapClose());
		elementClick(getBtngetsigcapVerification());
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnReturn());
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getReturnReason());
		Thread.sleep(1000);
		elementClick(getOptionMultilatedItem());
		elementClick(getBtnOverride());
		Thread.sleep(1000);
		if (getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		} else if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnReturn());
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getTapCloseIcon());
	}

	public void search_ItemFinder(String chequeNum, String chequeAmount) throws InterruptedException {
		// elementClick(getMenuIcon());
		elementClick(getInwardsearchitemFinder());
		elementInsertValue(getItemfinderChequeNum(), chequeNum);
		elementInsertValue(getItemfinderChequeAmount(), chequeAmount);
		elementClick(getBtnSearch());

	}

	public String chequeStatus() {
		String chequeStatus = elementGetText(getChequeStatus());
		return chequeStatus;

	}

	public void inwardChecker(String chequeNum) throws AWTException, InterruptedException {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		elementClick(getInwardTechnicalVerifier2());
		elementClick(getTxtVerifier2BussinessDate());
		elementClick(getInwardV1DateSelection());
		elementInsertValue(getTxtVerifier2ChequeNum(), chequeNum);
		elementClick(getBtnSearch());
		Thread.sleep(2000);
		elementClick(getChequelist1stlineVerifier2());
		Thread.sleep(3000);
		elementInsertValue(getTxtVerifier2AcctNum(), elementGetAttribute(getVerifier2AcctNum()));

	}

	public void inwardReturnByChecker() throws Exception {
		elementClick(getBtnsigcapVerification());
		Thread.sleep(1000);
		elementClick(getBtnsigcapClose());
		elementClick(getBtngetsigcapVerification());
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnReturn());
		Thread.sleep(2000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getReturnReason());
		Thread.sleep(2000);
		elementClick(getOptionMultilatedItemVerifier2());
		elementClick(getBtnOverride());
		Thread.sleep(1000);
		if (getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		} else if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnReturn());
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		elementClick(getTapCloseIcon());

	}

	public void inwardAcceptByMaker() throws InterruptedException, AWTException {
		elementClick(getBtnsigcapVerification());
		Thread.sleep(1000);
		elementClick(getBtnsigcapClose());
		elementClick(getBtngetsigcapVerification());
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnOverride());
		Thread.sleep(1000);
		if (getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		} else if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnAccept());
		Thread.sleep(10000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		elementClick(getTapCloseIcon());

	}

	public void inwardAcceptByChecker() throws InterruptedException, AWTException {
		elementClick(getBtnsigcapVerification());
		Thread.sleep(1000);
		Thread.sleep(1000);
		elementClick(getBtnsigcapClose());
		elementClick(getBtngetsigcapVerification());
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		elementClick(getBtnOverride());
		Thread.sleep(1000);
		if (getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		} else if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		elementClick(getBtnAccept());
		Thread.sleep(10000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		elementClick(getTapCloseIcon());
	}

	public void inwardParallelReferralProcessingAccept(String chequeNum) throws AWTException, InterruptedException {
		elementClick(getTapCloseIcon());
		elementClick(getInwardParallelReferralProcessing());
		elementClick(getTxtBussinessDateinwardReferral());
		elementClick(getInwardV1DateSelection());
		elementInsertValue(getTxtVerifier2ChequeNum(), chequeNum);
		elementClick(getBtnSearch());
		Thread.sleep(2000);
		elementClick(getReferralchequelist1stline());
		elementClick(getBtnSubmit());
		Thread.sleep(1000);
		if (getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		}
		Thread.sleep(1000);
		elementClick(getTapCloseIcon());

	}

	/*** below followed methods are Inward Field Verification Methods ***/

	/**
	 * @author parasuramk Inward Technical Verifier1 fields verification
	 */
	public boolean inwardTechnicalVerifier1isClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardTechnicalVerifier1().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifier1BDisMandatory() {
		elementClick(getInwardTechnicalVerifier1());
		elementClick(getBtnSearch());
		boolean displayed = getPlsSelectBDate().isDisplayed();
		return displayed;
	}

	public void acceptPopUpMsg() {
		if (getBtnOK().isDisplayed()) {
			elementClick(getBtnOK());
		} else if (getBtnYes().isDisplayed()) {
			elementClick(getBtnYes());
		}

	}

	public boolean inwardTechnicalVerifierSearchBtnisClickable() {
		boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}

	public void goToInwardTechnicalVerifier1BatchDetailsPage(String batchNum) throws InterruptedException {
		Thread.sleep(1000);
		elementClick(getTxtBusinessDate());
		explicitWait(5, getInwardV1DateSelection());
		elementClick(getInwardV1DateSelection());
		elementInsertValue(getTxtBatchNum(), batchNum);
		elementClick(getBtnSearch());

	}

	/** inwardTechnicalVerifier1BatchDetail method is to click first batch of list (Batch Details Page)*/

	public void inwardTechnicalVerifier1BatchDetailClick() {
		elementClick(getChequelist1stline());
	}

	public boolean inwardTechnicalVerifier1BatchDetailsareClickable() {
		boolean enabled = getChequelist1stline().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifierSigCapVerificationClickable() {
		boolean enabled = getBtnsigcapVerification().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifierGetSigCapClickable() {
		boolean enabled = getBtngetsigcapVerification().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifierOverrideClickable() {
		boolean enabled = getBtnOverride().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifierAcceptBtnClickable() {
		boolean enabled = getBtnAccept().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifierReturnBtnClickable() {
		boolean enabled = getBtnReturn().isEnabled();
		return enabled;
	}
	public boolean inwardTechnicalVerifierReturnExceptionBtnClickable() {
		boolean enabled = getBtnReturnException().isEnabled();
		return enabled;
	}
	public boolean inwardTechnicalVerifierSkipBtnClickable() {
		boolean enabled = getBtnSkip().isEnabled();
		return enabled;
	}
	
	/**
	 * @author parasuramk Inward Technical Verifier2 fields verification
	 */
	public boolean inwardTechnicalVerifier2isClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardTechnicalVerifier2().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifier2BDisMandatory() {
		elementClick(getInwardTechnicalVerifier2());
		elementClick(getBtnSearch());
		boolean displayed = getPlsSelectBDate().isDisplayed();
		return displayed;
	}

	public void goToInwardTechnicalVerifier2BatchDetailsPage(String batchNum) throws InterruptedException {
		Thread.sleep(1000);
		elementClick(getTxtVerifier2BussinessDate());
		explicitWait(5, getInwardV1DateSelection());
		elementClick(getInwardV1DateSelection());
		elementInsertValue(getTxtBatchNumVerifier2(), batchNum);
		elementClick(getBtnSearch());
	}

	public void inwardTechnicalVerifier2BatchDetailClick() {
		elementClick(getChequelist1stlineVerifier2());
	}

	public boolean inwardTechnicalVerifier2BatchDetailsareClickable() {
		boolean enabled = getChequelist1stlineVerifier2().isEnabled();
		return enabled;
	}
	public boolean inwardTechnicalVerifierSendBackBtnClickable() {
		boolean enabled = getBtnSendBack().isEnabled();
		return enabled;
	}
	/**
	 * @author ParasuramK Inward DashBoard Fields Verification methods
	 */
	public boolean inwardDashboardisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardDashboardmenu().isEnabled();
		return enabled;
	}
	public void inwardDashboard() {
		elementClick(getInwardDashboardmenu());
	}
	/**
	 * @author ParasuramK Inward Search/Item Finder fields verification
	 */
	public boolean inwardSearchItemFinderisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardsearchitemFinder().isEnabled();
		return enabled;
	}
	public void inwardSearchItemFinder() {
		elementClick(getInwardsearchitemFinder());
	}
	/**
	 * @author ParasuramK Inward Bank Wise Summary Dashboard fields verification
	 */
	public boolean inwardBankWiseSummaryDashboardisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardBankWiseSummaryDashboardmenu().isEnabled();
		return enabled;
	}
	public void inwardBankWiseSummaryDashboard() throws InterruptedException {
		elementClick(getInwardBankWiseSummaryDashboardmenu());
		Thread.sleep(1000);
		if(!getBtnRefresh().isDisplayed()) {
			elementClick(getBtnOK());
		}
	}
	/**
	 * @author ParasuramK Inward Central Bank Status Dashboard fields verification
	 */
	public boolean inwardCentralBankStatusDashboardisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardCentralBankStatusDashboardmenu().isEnabled();
		return enabled;
	}
	public void inwardCentralBankStatusDashboard() throws InterruptedException {
		elementClick(getInwardCentralBankStatusDashboardmenu());
		Thread.sleep(1000);
		if(!getBtnRefresh().isDisplayed()) {
			elementClick(getBtnOK());
		}
			
			
	}
	
	/**
	 * @author ParasuramK Inward Finacle Dashboard fields verification
	 */
	
	public boolean inwardFinacleDashboardisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardFinacleDashboardmenu().isEnabled();
		return enabled;
	}
	public void inwardFinacleDashboard() throws InterruptedException {
		elementClick(getInwardFinacleDashboardmenu());
		Thread.sleep(1000);
		if(!getBtnRefresh().isDisplayed()) {
			elementClick(getBtnOK());
		}
	}
	
	/**
	 * @author ParasuramK Inward Referral Dashboard fields verification
	 */
	
	public boolean inwardReferralDashboardisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardReferralDashboardmenu().isEnabled();
		return enabled;
	}
	public void inwardReferralDashboard() throws InterruptedException {
		elementClick(getInwardReferralDashboardmenu());
		Thread.sleep(1000);
		if(!getBtnRefresh().isDisplayed()) {
			elementClick(getBtnOK());
		}
	}
	/**
	 * @author ParasuramK Inward Userwise Dashboard fields verification
	 */
	public boolean inwardUserwiseDashboardisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardUserwiseDashboardmenu().isEnabled();
		return enabled;
	}
	public void inwardUserwiseDashboard() throws InterruptedException {
		elementClick(getInwardUserwiseDashboardmenu());
		Thread.sleep(1000);
		if(!getBtnRefresh().isDisplayed()) {
			elementClick(getBtnOK());
		}
	}
	
	/**
	 * @author ParasuramK Consolidated Posting Inward fields verification
	 */
	
	public boolean consolidatedPostingInwardisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getConsolidatedPostingInwardmenu().isEnabled();
		return enabled;
	}
	public void consolidatedPostingInward() {
		elementClick(getConsolidatedPostingInwardmenu());
		
	}
	/**
	 * @author ParasuramK Inward Technical Verifier1 Arabic fields verification
	 */
	
	public boolean inwardTechnicalVerifier1ArabicisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardTechnicalVerifier1Arabicmenu().isEnabled();
		return enabled;
	}
	public void inwardTechnicalVerifier1Arabic() {
		elementClick(getInwardTechnicalVerifier1Arabicmenu());

	}
	
	public boolean inwardTechnicalVerifierArabicBDisMandatory() {
		elementClick(getBtnSearch());
		boolean displayed = getPlsSelectBDate().isDisplayed();
		return displayed;
	}

	public boolean inwardTechnicalVerifierArabicSearchBtnisClickable() {
		boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}

	public void goToInwardTechnicalVerifierArabicBatchDetailsPage(String batchNum) throws InterruptedException {
		Thread.sleep(1000);
		elementClick(getTxtBusinessDate());
		explicitWait(5, getInwardV1DateSelection());
		elementClick(getInwardV1DateSelection());
		elementInsertValue(getTxtBatchNum(), batchNum);
		elementClick(getBtnSearch());
	}
	/**
	 * @author ParasuramK Inward Technical Verifier1 Arabic fields verification
	 */
	
	public boolean inwardTechnicalVerifier2ArabicisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardTechnicalVerifier2Arabicmenu().isEnabled();
		return enabled;
	}

	public boolean inwardTechnicalVerifier2ArabicBDisMandatory() {
		elementClick(getInwardTechnicalVerifier2Arabicmenu());
		elementClick(getBtnSearch());
		boolean displayed = getPlsSelectBDate().isDisplayed();
		return displayed;
	}

	public void goToInwardTechnicalVerifier2ArabicBatchDetailsPage(String batchNum) throws InterruptedException {
		Thread.sleep(1000);
		elementClick(getTxtVerifier2BussinessDate());
		explicitWait(5, getInwardV1DateSelection());
		elementClick(getInwardV1DateSelection());
		elementInsertValue(getTxtBatchNumVerifier2(), batchNum);
		elementClick(getBtnSearch());
	}

	public void inwardTechnicalVerifier2ArabicBatchDetailClick() {
		elementClick(getChequelist1stlineVerifier2());
	}

	public boolean inwardTechnicalVerifier2ArabicBatchDetailsareClickable() {
		boolean enabled = getChequelist1stlineVerifier2().isEnabled();
		return enabled;
	}
	
	
	/**
	 * @author ParasuramK Inward Reject Repair Maker fields verification
	 */
	public boolean rejectRepairMakerisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getRejectRepairMakerMenu().isEnabled();
		return enabled;
	}
	public void rejectRepairMaker() {
		elementClick(getRejectRepairMakerMenu());
	}
	public boolean rejectRepairMakerBDisMandatory() {
		elementClick(getBtnSearch());
		boolean displayed = getPlsSelectBDate().isDisplayed();
		return displayed;
	}
	public boolean rejectRepairMakerSearchBtnisClickable() {
		boolean enabled = getBtnSearch().isEnabled();
		return enabled;
	}
	/**
	 * @author ParasuramK Inward Reject Repair Maker Arabic fields verification
	 */
	public boolean rejectRepairMakerArabicisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getRejectRepairMakerArabicMenu().isEnabled();
		return enabled;
	}
	public void rejectRepairMakerArabic() {
		elementClick(getRejectRepairMakerArabicMenu());
	}
	/**
	 * @author ParasuramK Inward Branch Referral Crad fields verification
	 */
	
	public boolean inwardBranchReferralCradisClickable() {
		elementClick(getInwardProcessing());
		elementClick(getInwardClearing());
		boolean enabled = getInwardBranchReferralCradMenu().isEnabled();
		return enabled;
	}
	public void  inwardBranchReferralCrad() {
		elementClick(getInwardBranchReferralCradMenu());
	}
	
}
