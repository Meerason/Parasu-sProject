package com.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;

public class LoginPage extends BaseClass{
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="(//input[@class='textId z-textbox'])[1]")
	private WebElement txtUserName;
	
	@FindBy(xpath="(//input[@class='textId z-textbox'])[2]")
	private WebElement txtPassword;
	
	@FindBy(xpath="//label[text()='EMIRATES NBD']/preceding-sibling::input")
	private WebElement rdoEmiratesnbd;
	
	@FindBy(xpath="//label[text()='EMIRATES ISLAMIC']/preceding-sibling::input")
	private WebElement rdoEmiratesIslamic;
	
	@FindBy(xpath="//button[text()='Login']")
	private WebElement btnLogin;
	
	@FindBy(xpath="//span[@class='z-menu-text']")
	private WebElement logoutmenu;
	
	@FindBy(xpath="//span[text()='Login Successful!']")
	private WebElement successMsgPopUp;
	
	@FindBy(xpath="//span[text()='Logout']")
	private WebElement btnLogout;
	
	@FindBy(xpath="//button[text()='OK']")
	private WebElement btnOK;
	
	@FindBy(xpath="//button[text()='Yes']")
	private WebElement btnYes;
	
	@FindBy(xpath="/html/body/div[3]/div[2]/div[2]/div[2]/span")
	private WebElement failedMsg;
	
	public WebElement getLogoutmenu() {
		return logoutmenu;
	}

	public WebElement getTxtUserName() {
		return txtUserName;
	}

	public WebElement getBtnLogout() {
		return btnLogout;
	}

	public WebElement getTxtPassword() {
		return txtPassword;
	}

	public WebElement getRdoEmiratesnbd() {
		return rdoEmiratesnbd;
	}

	public WebElement getRdoEmiratesIslamic() {
		return rdoEmiratesIslamic;
	}

	public WebElement getBtnLogin() {
		return btnLogin;
	}

	public WebElement getBtnOK() {
		return btnOK;
	}

	public WebElement getBtnYes() {
		return btnYes;
	}

	public WebElement getFailedMsg() {
		return failedMsg;
	}

	public WebElement getSuccessMsgPopUp() {
		return successMsgPopUp;
	}

	public void login(String userName, String password)  {
		elementInsertValue(getTxtUserName(), userName);
		elementInsertValue(getTxtPassword(), password);
		elementClick(getBtnLogin());
	}
		public void loginPopMsg() throws InterruptedException{	
		Thread.sleep(3000);
		if(getBtnOK().isDisplayed()){
			elementClick(getBtnOK());
		}else if(getBtnYes().isDisplayed()){
			elementClick(getBtnYes());
		}

	}
	public void logout() throws InterruptedException {
		elementClick(getLogoutmenu());
		Thread.sleep(1000);
		elementClick(getBtnLogout());

	}
}
