package com.base;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public static WebDriver driver;

	public void getDriver(String browserType) {

		switch (browserType) {
		case "chrome":
			driver = new ChromeDriver();
			break;
		case "firefox":
			driver = new FirefoxDriver();
			break;
		case "ie":
			driver = new InternetExplorerDriver();
			break;
		case "edge":
			driver = new EdgeDriver();
			break;
		default:
			break;

		}
	}

	public static String getProjectPath() {
		String path = System.getProperty("user.dir");
		return path;
	}
	public String getInputValue(WebElement element) {
		String textBoxValue = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].value;", element);
		return textBoxValue;
//	    String js2 = "return arguments[0].querySelector('input').value";
//	    JavascriptExecutor js = (JavascriptExecutor) driver;
//	    return js.executeScript(js2, element).toString();
	}

	public static String getPropertyFileValue(String key) throws FileNotFoundException, IOException {
		Properties properties = new Properties();
		properties.load(new FileInputStream(getProjectPath() + "\\Config\\config.properties"));
		Object object = properties.get(key);
		String value = (String) object;
		return value;

	}

	// launch browser

	public static void getChromeDriver() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

	}

	// Launch URL

	public static void enterApplUrl(String url) {
		driver.get(url);
	}

	public static void maximizewindow() {
		driver.manage().window().maximize();
	}

	public static void elementInsertValue(WebElement element, String data) {
		element.sendKeys(data);
	}

	public static void elementClick(WebElement element) {
		element.click();
	}

	/**
	 * @see used to click Alert Ok
	 */
	public static void clickAlertOk() {
		Alert alert = driver.switchTo().alert();
		alert.accept();

	}

	/**
	 * @see used to click Alert Cancel
	 */
	public void clickAlertCancel() {
		Alert alert = driver.switchTo().alert();
		alert.dismiss();

	}

	/**
	 * @see used to element Get Text
	 * @param element
	 * @return String
	 */
	public String elementGetText(WebElement element) {
		String text = element.getText();
		return text;

	}

	/**
	 * @see used to element Get Attribute
	 * @param element
	 * @return String
	 */
	public static String elementGetAttribute(WebElement element) {
		String attribute = element.getAttribute("value");
		return attribute;
	}

	/**
	 * @see used to close All Window
	 */
	public void quitWindow() {
		driver.quit();

	}

	/**
	 * @see used to close Current Win
	 */
	public void closeCurrentWin() {
		driver.close();

	}

	/**
	 * @see used to get Title
	 * @return String
	 */
	public String getTitle() {
		String title = driver.getTitle();
		return title;

	}

	/**
	 * @see used to Get Enter Url
	 * @return String
	 */
	public String GetEnterUrl() {
		String currentUrl = driver.getCurrentUrl();
		return currentUrl;

	}

	/**
	 * @see used to dropDown By Text
	 * @param element
	 * @param data
	 */

	public void dropDownByText(WebElement element, String data) {
		Select s = new Select(element);
		s.selectByVisibleText(data);

	}

	/**
	 * @see used to dropDown By Attribute
	 * @param element
	 * @param data
	 */
	public void dropDownByAttribute(WebElement element, String data) {
		Select s = new Select(element);
		s.selectByValue(data);
	}

	/**
	 * @see used to dropDown Index
	 * @param element
	 * @param index
	 */
	public void dropDownIndex(WebElement element, int index) {
		Select s = new Select(element);
		s.selectByIndex(index);
	}

	/**
	 * @see used to insert Value By JavaScript
	 * @param element
	 * @param data
	 */
	public void insertValueByJs(WebElement element, String data) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("argument[0].setAttribute('value" + data + "')", element);

	}

	/**
	 * @see used to click button By javascript
	 */
	public void clickBtnByJs(WebElement element, String data) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", element);
	}

	/**
	 * @see used to switch child Window
	 * @param childwin
	 */
	public void childWindow(String childwin) {
		driver.switchTo().window(childwin);

	}

	/**
	 * @see used to switch to particular Frame Index
	 * @param index
	 */
	public void switchtoFrameIndex(int index) {
		driver.switchTo().frame(index);
	}

	/**
	 * @see used to switch To particular Frame Id
	 * @param id
	 */
	public void switchToFrameId(String id) {
		driver.switchTo().frame(id);

	}

	/**
	 * @see used to locator By Id
	 * @param attributeValue
	 * @return WebElement
	 */
	public static WebElement locatorById(String attributeValue) {
		WebElement findElement = driver.findElement(By.id(attributeValue));
		return findElement;
	}

	/**
	 * @see used to locator By Name
	 * @param attributeValue
	 * @return WebElement
	 */
	public WebElement locatorByName(String attributeValue) {
		WebElement findElement = driver.findElement(By.name(attributeValue));
		return findElement;

	}

	/**
	 * @see used to locator By Xpath
	 * @param xpathExp
	 * @return WebElement
	 */
	public WebElement locatorByXpath(String xpathExp) {
		WebElement findElement = driver.findElement(By.xpath(xpathExp));
		return findElement;

	}

	/**
	 * @see used to get all options from dropdown as text
	 * @param element
	 * @return List<WebElement>
	 */
	public List<WebElement> ddalloptiontext(WebElement element) {
		Select s = new Select(element);
		// String text1 = element.getText();
		// s.selectByVisibleText(text1);
		List<WebElement> options = s.getOptions();
		for (int i = 0; i < options.size(); i++) {
			WebElement webElement = options.get(i);
			String text = webElement.getText();
			System.out.println(text);
		}
		return options;
	}

	/**
	 * @see used to get all options from dropdown as attribute
	 * @param element
	 * @param value
	 * @return List<WebElement>
	 */
	public List<WebElement> ddalloptioninattribute(WebElement element, String value) {
		Select s = new Select(element);
		// String attribute = element.getAttribute(value);
		// s.selectByValue(attribute);
		List<WebElement> options = s.getOptions();
		for (int i = 0; i < options.size(); i++) {
			WebElement webElement = options.get(i);
			String text = webElement.getAttribute(value);
			System.out.println(text);
		}
		return options;

	}

	/**
	 * @see used to get first selected option text in dropdown
	 * @param element
	 * @return String
	 */
	public String dropDownFirstSelectedTxt(WebElement element) {
		Select s = new Select(element);
		WebElement firstSelectedOption = s.getFirstSelectedOption();
		String text = firstSelectedOption.getText();
		return text;
	}

	/**
	 * @see used to dropDown Multi Selected
	 * @param element
	 * @return boolean
	 */
	public boolean dropDownMultiSelected(WebElement element) {
		Select s = new Select(element);
		boolean multiple = s.isMultiple();
		return multiple;
	}

	/**
	 * @see used to implicit Wait
	 * @param sec
	 */
	public void implicitWait(int sec) {
		driver.manage().timeouts().implicitlyWait(sec, TimeUnit.SECONDS);

	}

	/**
	 * @see used to explicit Wait
	 * @param seconds
	 * @param idvalue
	 * @return boolean
	 */
	public void explicitWait(long seconds, WebElement element) {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		w.until(ExpectedConditions.elementToBeClickable(element));
		
		//invisibilityOfElementLocated(By.id(idvalue))
	}
	public void explicitWaitelementvisible(long seconds, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		
				wait.until(ExpectedConditions.visibilityOf(element));
		//invisibilityOfElementLocated(By.id(idvalue))
	}

	/**
	 * @see used to fluent wait
	 * @param sec
	 * @param sec1
	 */
	public void fluentwait(long sec, long sec1) {
		Wait wait = new FluentWait(driver).withTimeout(Duration.ofSeconds(sec)).pollingEvery(Duration.ofSeconds(sec1))
				.ignoring(Throwable.class);
	}

	/**
	 * @see used to check element is Displayed
	 * @param element
	 * @return boolean
	 */
	public boolean isDisplayed(WebElement element) {
		boolean displayed = element.isDisplayed();
		return displayed;
	}


	/**
	 * @see used to deselect By Index
	 * @param element
	 * @param index
	 */
	public void deselectByIndex(WebElement element, int index) {
		Select s = new Select(element);
		s.deselectByIndex(index);

	}

	/**
	 * @see used to deselect By Attribute
	 * @param element
	 * @param value
	 */
	public void deselectByAttribute(WebElement element, String value) {
		Select s = new Select(element);
		s.deselectByValue(value);

	}

	/**
	 * @see used to deselect By Text
	 * @param element
	 * @param text
	 */
	public void deselectByText(WebElement element, String text) {
		Select s = new Select(element);
		s.deselectByVisibleText(text);

	}

	/**
	 * @see used to deselect All
	 * @param element
	 */
	public void deselectAll(WebElement element) {
		Select s = new Select(element);
		s.deselectAll();

	}

	/**
	 * @see used to get parent window
	 * @return String
	 */
	public String parWindowGent() {
		String windowHandle = driver.getWindowHandle();
		return windowHandle;

	}

	/**
	 * @see used to get all Window
	 * @param element
	 * @return Set<String>
	 */
	public Set<String> allWindow(WebElement element) {
		Set<String> windowHandles = driver.getWindowHandles();
		return windowHandles;

	}

	/**
	 * @see used to clear Text Box
	 * @param element
	 */
	public void clearTextBox(WebElement element) {
		element.clear();

	}

//	/**
//	 * @see used to Take Screenshot
//	 */
//
//	public void takescreeshotElement(WebElement element) {
//		TakesScreenshot screenshot = (TakesScreenshot) driver;
//		File screenshotAs = screenshot.getScreenshotAs(OutputType.FILE);
//		FileUtils.copyFile(SrcFile, DestFile);
//
//	}

	/**
	 * @see used to mouseover on single Option
	 * @param driver
	 * @param element
	 */
	public void singleOptionMouseover(WebDriver driver, WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element).perform();

	}

	/**
	 * @see used to drag And Drop
	 * @param source
	 * @param target
	 */
	public void dragAndDrop(WebElement source, WebElement target) {
		Actions actions = new Actions(driver);
		actions.dragAndDrop(source, target).perform();

	}

	/**
	 * @see used to rightClick
	 */
	public void rightClick() {
		Actions actions = new Actions(driver);
		actions.contextClick().perform();

	}

	/**
	 * @see used to doubleClick
	 */
	public void doubleClick() {
		Actions actions = new Actions(driver);
		actions.doubleClick().perform();

	}

	/**
	 * @see used to insert Value And Enter
	 * @param element
	 * @param value
	 */
	public void insertValueAndEnter(WebElement element, String value) {
		element.sendKeys("Value", Keys.ENTER);

	}

	/**
	 * @see used to refresh Page
	 */
	public void refreshPage() {
		driver.navigate().refresh();

	}

	/**
	 * @see used to forward Page
	 */
	public void forwardPage() {
		driver.navigate().forward();

	}

	/**
	 * @see used to back Page
	 */
	public void backPage() {
		driver.navigate().back();

	}

	/**
	 * @see used to navigate To url
	 * @param url
	 */
	public void navigatTo(String url) {
		Navigation navigate = driver.navigate();
		navigate.to(url);
	}

	/**
	 * @see used to key Press
	 * @param keycode
	 * @throws AWTException
	 */
	public void keyPress(int keycode) throws AWTException {
		Robot robot = new Robot();
		robot.keyPress(keycode);

	}

	/**
	 * @see used to key Release
	 * @param keycode
	 * @throws AWTException
	 */
	public void keyRelease(int keycode) throws AWTException {
		Robot robot = new Robot();
		robot.keyRelease(keycode);

	}

	/**
	 * @see used to key Up
	 * @param target
	 * @param key
	 */
	public void keysUp(WebElement target, CharSequence key) {
		Actions actions = new Actions(driver);
		actions.keyUp(target, key);

	}

	/**
	 * @see used to key Down
	 * @param target
	 * @param key
	 */
	public void keyDown(WebElement target, CharSequence key) {
		Actions actions = new Actions(driver);
		actions.keyDown(target, key).perform();

	}

	/**
	 * @see used to dropDown All Selected Option
	 * @param element
	 * @return String
	 */
	public String dropDownAllSelectedOption(WebElement element) {
		Select s = new Select(element);
		List<WebElement> options = s.getAllSelectedOptions();
		for (int i = 0; i < options.size(); i++) {
			WebElement webElement = options.get(i);
			String text = webElement.getText();
			return text;

		}
		return null;

	}

}
