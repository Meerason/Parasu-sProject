package com.enbd;


public class Testnewi {
	static int a =0,b=4,c=1,value;
	public static void main(String[] args) {
//		String s="Application is licensed to - 'ENBD & EI'.\r\n" + 
//				"Unauthorized use of this application is prohibited.";
//		System.out.println(s);
//		int length = s.length();
//		System.out.println(length);
//		String substring = s.substring(43, 94);
//		System.out.println(substring);
		
		
		
//		String s="400";
//		
//		String replaceAll = s.replaceAll(",","");
//		System.out.println(replaceAll);
//		double parseDouble = Double.parseDouble(replaceAll);
//		System.out.println(parseDouble);
//		if(parseDouble==400) {
//			System.out.println("ok da dai");
//			}
//		if (s=="400") {
//			System.out.println("ok than");
//			System.out.println("\u001B[35mPurple text");
//			System.out.println("\u001B[31mRed text");
//			System.out.println("\u001B[32mGreen text");
//			System.out.println("\u001B[33mYellow text");
//			System.out.println("\u001B[34m Blue text");
//			System.out.println("\u001B[35m" + "Purple text");
//			System.out.println("\u001B[36mCyan text");
//			System.out.println("\u001B[37mWhite text");
//			System.out.println("\u001B[1m");
//			System.out.println("\u001B[4m");
//			
//		}
		
		try {value=b/c;}
		catch(ArithmeticException e) {
			System.out.println("catch");
		}
		System.out.println(value);
	}

}
