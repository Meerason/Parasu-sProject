package com.enbd;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.base.BaseClass;
import com.manager.PageObjectManager;
import com.pages.LoginPage;
import com.pages.OnusTechnicalVerification;

public class Chromein extends BaseClass {

	public static void main(String[] args) throws Exception {
		PageObjectManager pom = new PageObjectManager();
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\PARASURAMK\\Java\\chromedriver-win64\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://ecuat.enbduat.com/expressClear_ENBD/index.zul");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement advanced = driver.findElement(By.xpath("//button[contains(text(),'Advanced')]"));
		advanced.click();
		WebElement advuat = driver.findElement(By.xpath("//a[text()='Proceed to ecuat.enbduat.com (unsafe)']"));
		advuat.click();
		Thread.sleep(1000);
		
		
		
		
//		driver.findElement(By.xpath("(//input[@class='textId z-textbox'])[1]")).sendKeys("TESTUSER14");
//		driver.findElement(By.xpath("(//input[@class='textId z-textbox'])[2]")).sendKeys("Enbd@123");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
		driver.findElement(By.xpath("//button[text()='Login']")).click();
		
		WebElement txt = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div[2]/div[2]/span"));
		//WebElement failedMsg = pom.getLoginPage().getFailedMsg();
		Thread.sleep(1000);
		   String actFailedMsg = txt.getText();
		   System.out.println(actFailedMsg);

	}
}
