@login
Feature: ExpressClear Login verification

  
  Scenario Outline: Login with valid credential
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"

    Examples: 
      | userName | password     |
      #| TESTUSER14 | Enbd@123 |
      | ECPT0008 | Automata@123 |

  Scenario Outline: Login with Invalid credentials
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login Failed message "Unauthorized use of this application is prohibited."

    Examples: 
      | userName | password   |
      | username | Eclear@123 |

  Scenario: Click Login button without credentials
    Given User is on the ExpressClear LoginPage
    When User perform login without credentials
    Then User should verify after login Failed message "Unauthorized use of this application is prohibited."
