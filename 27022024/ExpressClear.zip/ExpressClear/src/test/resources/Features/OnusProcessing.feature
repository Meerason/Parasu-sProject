Feature: ExpressClear Onus Process Verification

  @onusReturn
  Scenario Outline: Onus Technical verification and Return Cheque
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    When User is on Onus Technical Verification "<batchNumber>"
    And User update the amount and return Cheque by maker in Onus "<chequeAmount>"
    And Cheque with above the specified limit Login with Checker for Onus "<chkuserName>","<chkpassword>"
    Then User verifying Cheque status in SearchItemFinder

    Examples: 
      | userName | password     | batchNumber | chkuserName | chkpassword  | chequeAmount |
      # | TESTUSER14 | Enbd@123 | 1006_124      | TESTUSER16  | Enbd@123    |        10350 |
      | ECPT0008 | Automata@123 | 830_218     | ECPT0010    | Automata@123 |        10110 |

  @onusAccept
  Scenario Outline: Onus Technical verification and Accept Cheque
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    When User is on Onus Technical Verification "<batchNumber>"
    And User update the amount and Accept Cheque by maker in Onus "<chequeAmount>"
    And Cheque with above the specified limit Login with Checker for Onus and accept "<chkuserName>","<chkpassword>"
    Then User verifying Cheque status in SearchItemFinder

    Examples: 
      | userName | password     | batchNumber | chkuserName | chkpassword  | chequeAmount |
      #| TESTUSER14 | Enbd@123 | 011_112     | TESTUSER16  | Enbd@123    |        13550 |
      | ECPT0008 | Automata@123 | 830_218     | ECPT0010    | Automata@123 |        12250 |

  #@onusFieldVerification
  #Scenario Outline: Onus Branch Cheque Capture Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User verify Onus Branch Cheque Capture Is Clickable
    #Then User Verify Presentation Type is Mandatory
    #Then User Verify Scanner Type is Mandadtory
    #Then User Verify Initialize button is Clickable
    #Then User Verify Start button is Clickable
    #Then User Verify Stop button is Clickable
    #Then User Verify Finish button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| ECPT0008 | Automata@123 | 830_218     |

  #@onusFieldVerification
  #Scenario Outline: Scan Verification Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Scan Verification Is Clickable
    #Then User Verify The Business Date Mandatory Field
    #Then User Verify Search button Is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| ECPT0008 | Automata@123 | 830_218     |

  #@onusFieldVerification
  #Scenario Outline: Onus OPC Reject Repair Maker Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus OPC Reject Repair Maker Is Clickable
    #Then User Verify The OPC Reject Repair Maker Business Date is Mandatory Field
    #Then User Verify OPC Reject Repair Maker Search button Is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  @onusFieldVerification
  Scenario Outline: Onus tech verification1 Field Verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Onus technical verification1 Is Clickable
    Then User Verify The Business Date Mandatory Field
    Then User Verify Search button Is Clickable
    Then User Verify Batch details Clickable
    Then User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Clickable
    Then User Verify Accept ,Return, return exception,delete &skip button Is Clickable

    Examples: 
      | userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      | ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus tech verification1 Arabic Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus technical verification1 Arabic Is Clickable
    #Then User Verify The Business Date Mandatory Field
    #Then User Verify Search button Is Clickable
    #Then User Verify Batch details Clickable & Cheque detail are avl
    #Then User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Clickable
    #Then User Verify Accept ,Return, return exception,delete &skip button Is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus tech verification2 Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus technical verification2 Is Clickable
    #Then User Verify The Business Date Mandatory Field
    #Then User Verify Search button Is Clickable
    #Then User Verify Batch details Clickable & Cheque detail are avl
    #Then User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Clickable
    #Then User Verify Accept ,Return, return exception,delete &skip button Is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus tech verification2 Arabic Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus technical verification2 Arabic Is Clickable
    #Then User Verify The Business Date Mandatory Field
    #Then User Verify Search button Is Clickable
    #Then User Verify Batch details Clickable
    #Then User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Clickable
    #Then User Verify Accept ,Return, return exception,delete &skip button Is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Physical Cheque Validation Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Physical Cheque validation is Clickable
    #Then User Verify The Physical Cheque Validation Business Date is Mandatory Field
    #Then User Verify Physical Cheque Validation Search button Is Clickable
    #Then User Verify Physical Cheque Validation Batch details Clickable
    #Then User Verify Back,Verify & Delete button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Checkerwise Verified SatusField Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Checker Wise Verified Status is Clickable
    #Then User Verify Checker Wise Verified Status Refresh button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |

  #@onusFieldVerification
  #Scenario Outline: Makerwise Processing status Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Makerwise Processing Status is Clickable
    #Then User Verify Makerwise Processing status Refresh button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus ChannelWise Processing Status Dashboard Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus ChannelWise Processing Status Dashboard is Clickable
    #Then User Verify Onus ChannelWise Processing Status Dashboard Refresh button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus Finacle Dashboard Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus Finacle Dashboard is Clickable
    #Then User Verify Onus Finacle Dashboard Refresh button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus Refferal Dashboard Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus Refferal Dashboard is Clickable
    #Then User Verify Onus Refferal Dashboard Refresh button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus Branch Referral Crad Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus Branch Referral Crad Is Clickable
    #Then User Verify Onus Branch Referral Crad The Business Date Mandatory Field
    #Then User Verify Onus Branch Referral Crad Search button Is Clickable
    #Then User Verify Onus Branch Referral Crad Batch details are Clickable
    #Then User Verify Onus Branch Referral Crad Back,Accept & Return button is Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus Dashboard Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus Dashboard is Clikable
    #Then User Verify Total Cheque Scanned- plus icon is Clikable
    #Then User Verify QR Code Validation- plus icon is Clikable
    #Then User Verify ICR Service- plus icon is Clikable
    #Then User Verify Technical Verification I with Data Entry (OPC)- plus icon is Clikable
    #Then User Verify Technical Verification II (OPC)- plus icon is Clikable
    #Then User Verify Branch Referral Crad- plus icon is Clikable
    #Then User Verify Posting to Finacle- plus icon is Clikable
    #Then User Verify ACE File Creation- plus icon is Clikable
    #Then User Verify ACE ACK File Parsing- plus icon is Clikable
    #Then User Verify NACK Reject Reprocessing- plus icon is Clikable
    #Then User Verify Channel Wise cheque Status Count- plus icon is Clikable
    #Then User Verify Finacle- plus icon is Clikable
    #Then User Verify Awaiting- plus icon is Clikable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus OPC Arabic Reject Repair Maker Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus OPC Arabic Reject Repair Maker Is Clickable
    #Then User Verify Onus OPC Arabic Reject Repair Maker Business Date is Mandatory Field
    #Then User Verify Onus OPC Arabic Reject Repair Maker Search button Is Clickable
    #Then User Verify Onus OPC Arabic Reject Repair Maker Batch details Clickable
    #Then User Verify Onus OPC Arabic Reject Repair Maker Delete,Back & Release Lock button Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
#
  #@onusFieldVerification
  #Scenario Outline: Onus Parallel Referral Processing Field Verification
    #Given User is on the ExpressClear LoginPage
    #When User perform login "<userName>","<password>"
    #Then User should verify after login success message "Login Successful!"
    #Then User Verify Onus Parallel Referral Processing Is Clickable
    #Then User Verify Onus Parallel Referral Processing Business Date is Mandatory Field
    #Then User Verify Onus Parallel Referral Processing Search button Is Clickable
    #Then User Verify Onus Parallel Referral Processing Batch details Clickable
    #Then User Verify Onus Parallel Referral Processing Back,Accept & Return button Clickable
#
    #Examples: 
      #| userName | password     | batchNumber |
      #| TESTUSER14 | Enbd@123 | 011_112     |
      #| ECPT0008 | Automata@123 | 830_218     |
