Feature: ExpressClear Inward Process Verification

  @inwardReturn
  Scenario Outline: Inward Technical Verifier and Return Cheque
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    When User is on Inward Technical Verifier1 "<batchNumber>"
    And User return Cheque by maker
    And Cheque with above the specified limit Login with Checker "<chkuserName>","<chkpassword>"
    Then User verifying Cheque status

    Examples: 
      | userName | password     | batchNumber | chkuserName | chkpassword  |
      #| TESTUSER14 | Enbd@123 |    34900083 | TESTUSER16  | Enbd@123    |
      | ECPT0008 | Automata@123 |    05300157 | ECPT0010    | Automata@123 |

  @inwardAccept
  Scenario Outline: Inward Technical Verifier and Accept Cheque
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    When User is on Inward Technical Verifier1 "<batchNumber>"
    And User accept Cheque by maker
    And Cheque with above the specified limit Login with Checker and accept "<chkuserName>","<chkpassword>"
    Then User verifying Cheque status

    Examples: 
      | userName | password     | batchNumber | chkuserName | chkpassword  |
      #| TESTUSER14 | Enbd@123 |    02400001 | TESTUSER16  | Enbd@123    |
      | ECPT0008 | Automata@123 |    05300099 | ECPT0010    | Automata@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Technical Verifier1 fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Technical Verifier1 Is Enabled
    Then User Verify The Business Date Mandatory Field for Inward Technical Verifier1
    Then User Verify Search button Is Enabled on Inward Technical Verifier1
    When User go to Inward Technical Verifier1 Batch details Page "<batchNumber>"
    Then User Verify Batch details Clickable on Inward Technical Verifier1
    Then User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier1
    Then User Verify Accept ,Return, return exception & skip button Is Enabled on Inward Technical Verifier1

    Examples: 
      | userName | password     | batchNumber |
      | ECPT0008 | Automata@123 |    05300111 |

  @inwardFieldVerification
  Scenario Outline: Inward Technical Verifier2 fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Technical Verifier2 Is Enabled
    Then User Verify The Business Date Mandatory Field for Inward Technical Verifier2
    Then User Verify Search button Is Enabled on Inward Technical Verifier2
    When User go to Inward Technical Verifier2 Batch details Page "<batchNumber>"
    Then User Verify Batch details Clickable on Inward Technical Verifier2
    Then User Verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier2
    Then User Verify Accept ,Return, Return Exception,Send Back & Skip button Is Enabled on Inward Technical Verifier2

    Examples: 
      | userName | password     | batchNumber |
      | ECPT0010 | Automata@123 |    05300101 |

  @inwardFieldVerification
  Scenario Outline: Inward Dashboard fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Dashboard is Enabled
    Then User Verify Inward Parsing- plus icon is Enabled on Inward Dashboard
    Then User Verify QR Code Validation- plus icon is Enabled on Inward Dashboard
    Then User Verify OCR Service- plus icon is Enabled on Inward Dashboard
    Then User Verify DSA Validation- plus icon is Enabled on Inward Dashboard
    Then User Verify ASV Status- plus icon is Enabled on Inward Dashboard
    Then User Verify ICR Service- plus icon is Enabled on Inward Dashboard
    Then User Verify Technical Verification1 (OPC)- plus icon is Enabled on Inward Dashboard
    Then User Verify OPC Technical Verification2 (OPC)- plus icon is Enabled on Inward Dashboard
    Then User Verify Referral Branch Referral Crad- plus icon is Enabled on Inward Dashboard
    Then User Verify Posting to Finacle- plus icon is Enabled on Inward Dashboard
    Then User Verify Active CR- plus icon is Enabled on Inward Dashboard
    Then User Verify RCE File Creation- plus icon is Enabled on Inward Dashboard
    Then User Verify RAK File Parsing- plus icon is Enabled on Inward Dashboard
    Then User Verify NACK Reject Reprocessing- plus icon is Enabled on Inward Dashboard
    Then User Verify Finacle- plus icon is Enabled on Inward Dashboard
    Then User Verify Awaiting- plus icon is Enabled on Inward Dashboard

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Search/Item Finder fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Search/Item Finder is Enabled on Inward Dashboard
    Then User Verify Search button Is Enabled on Inward Search/Item Finder

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Bank Wise Summary Dashboard fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Bank Wise Summary Dashboard Option is clickable
    Then User Verify Refresh button is Enabled on Inward Bank Wise Summary Dashboard

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Central Bank Status Dashboard fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Central Bank Status Dashboard Option is clickable
    Then User Verify Refresh button is Enabled on Inward Central Bank Status Dashboard

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Finacle Dashboard fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Finacle Dashboard Option is clickable
    Then User Verify Refresh button is Enabled on Inward Finacle Dashboard

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Referral Dashboard fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Referral Dashboard Option is clickable
    Then User Verify Refresh button is Enabled on Inward Referral Dasboard

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Userwise Dashboard fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Userwise Dashboard Option is clickable
    Then User Verify Refresh button is Enabled on Inward Userwise Dasboard

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Consolidated Posting Inward fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Consolidated Posting Inward Option is clickable

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  #@inwardFieldVerification
  #Scenario Outline: Inward Technical Verifier1 Arabic fields verification
  #Given User is on the ExpressClear LoginPage
  #When User perform login "<userName>","<password>"
  #Then User should verify after login success message "Login Successful!"
  #Then User Verify Inward Technical Verifier1 Arabic Option Is Enabled
  #Then User Verify The Business Date Mandatory Field for Inward Technical Verifier1 Arabic
  #Then User Verify Search button Is Enabled on Inward Technical Verifier1 Arabic
  #When User go to Inward Technical Verifier1 Arabic Batch details Page "<batchNumber>"
  #Then User Verify Batch details are Clickable on Inward Technical Verifier1 Arabic
  #Then User verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier1 Arabic
  #Then User Verify Accept ,Return, Return Exception & Skip button Is Enabled on Inward Technical Verifier1 Arabic
  #
  #Examples:
  #| userName | password     | batchNumber |
  #| ECPT0008 | Automata@123 |    34900083 |
  #
  #@inwardFieldVerification
  #Scenario Outline: Inward Technical Verifier2 Arabic fields verification
  #Given User is on the ExpressClear LoginPage
  #When User perform login "<userName>","<password>"
  #Then User should verify after login success message "Login Successful!"
  #Then User Verify Inward Technical Verifier2 Arabic Option Is Enabled
  #Then User Verify The Business Date Mandatory Field for Inward Technical Verifier2 Arabic
  #Then User Verify Search button Is Enabled on Inward Technical Verifier2 Arabic
  #When User go to Inward Technical Verifier2 Arabic Batch details Page "<batchNumber>"
  #Then User Verify Batch details are Clickable on Inward Technical Verifier2 Arabic
  #Then User verify Sigcap Verification ,getSigcapresult & Override Btn Is Enabled on Inward Technical Verifier2 Arabic
  #Then User verify Accept ,Return, Return Exception, Send back & Skip button Is Enabled on Inward Technical Verifier2 Arabic
  #
  #Examples:
  #| userName | password     | batchNumber |
  #| ECPT0008 | Automata@123 |    34900083 |
  @inwardFieldVerification
  Scenario Outline: Inward Reject Repair Maker fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Reject Repair Maker Is Enabled
    Then User Verify The Business Date Mandatory Field for Inward Reject Repair Maker
    Then User Verify Search button Is Enabled on Inward Reject Repair Maker

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Reject Repair Maker Arabic fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Reject Repair Maker Arabic Is Enabled
    Then User Verify The Business Date Mandatory Field for Reject Repair Maker Arabic
    Then User Verify Search button Is Enabled on Reject Repair Maker Arabic

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |

  @inwardFieldVerification
  Scenario Outline: Inward Branch Referral Crad fields verification
    Given User is on the ExpressClear LoginPage
    When User perform login "<userName>","<password>"
    Then User should verify after login success message "Login Successful!"
    Then User Verify Inward Branch Referral Crad Option Is Enabled
    Then User Verify The Business Date Mandatory Field for Branch Referral Crad
    Then User Verify Search button Is Enabled on Branch Referral Crad

    Examples: 
      | userName   | password |
      | TESTUSER14 | Enbd@123 |
